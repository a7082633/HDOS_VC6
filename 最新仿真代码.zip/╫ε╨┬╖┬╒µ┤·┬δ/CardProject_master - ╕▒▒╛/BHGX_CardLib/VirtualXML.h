#pragma once

class CVirtualXML
{
public:
	CVirtualXML(void);
	~CVirtualXML(void);


};

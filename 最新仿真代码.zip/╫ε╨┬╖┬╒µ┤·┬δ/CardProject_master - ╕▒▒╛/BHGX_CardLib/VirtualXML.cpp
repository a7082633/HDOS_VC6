#include "VirtualXML.h"

CVirtualXML::CVirtualXML(void)
{
}

CVirtualXML::~CVirtualXML(void)
{
}

//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by BHGX_CardLib.rc
//
#define IDR_XML                         101
#define IDR_XML1                        104
#define IDR_XML2                        105
#define IDR_XML3                        108
#define IDR_XML4                        110
#define IDR_XML5                        115
#define IDR_XML6                        116
#define IDR_XML7                        117

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        111
#define _APS_NEXT_COMMAND_VALUE         40003
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif

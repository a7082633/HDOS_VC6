

/* this ALWAYS GENERATED file contains the proxy stub code */


 /* File created by MIDL compiler version 6.00.0366 */
/* at Thu Nov 19 01:38:21 2015
 */
/* Compiler settings for .\BHGX_CardActiveX.idl:
    Oicf, W1, Zp8, env=Win32 (32b run)
    protocol : dce , ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
    VC __declspec() decoration level: 
         __declspec(uuid()), __declspec(selectany), __declspec(novtable)
         DECLSPEC_UUID(), MIDL_INTERFACE()
*/
//@@MIDL_FILE_HEADING(  )

#if !defined(_M_IA64) && !defined(_M_AMD64)


#pragma warning( disable: 4049 )  /* more than 64k source lines */
#if _MSC_VER >= 1200
#pragma warning(push)
#endif
#pragma warning( disable: 4100 ) /* unreferenced arguments in x86 call */
#pragma warning( disable: 4211 )  /* redefine extent to static */
#pragma warning( disable: 4232 )  /* dllimport identity*/
#pragma optimize("", off ) 

#define USE_STUBLESS_PROXY


/* verify that the <rpcproxy.h> version is high enough to compile this file*/
#ifndef __REDQ_RPCPROXY_H_VERSION__
#define __REQUIRED_RPCPROXY_H_VERSION__ 440
#endif


#include "rpcproxy.h"
#ifndef __RPCPROXY_H_VERSION__
#error this stub requires an updated version of <rpcproxy.h>
#endif // __RPCPROXY_H_VERSION__


#include "BHGX_CardActiveX.h"

#define TYPE_FORMAT_STRING_SIZE   67                                
#define PROC_FORMAT_STRING_SIZE   2069                              
#define TRANSMIT_AS_TABLE_SIZE    0            
#define WIRE_MARSHAL_TABLE_SIZE   1            

typedef struct _MIDL_TYPE_FORMAT_STRING
    {
    short          Pad;
    unsigned char  Format[ TYPE_FORMAT_STRING_SIZE ];
    } MIDL_TYPE_FORMAT_STRING;

typedef struct _MIDL_PROC_FORMAT_STRING
    {
    short          Pad;
    unsigned char  Format[ PROC_FORMAT_STRING_SIZE ];
    } MIDL_PROC_FORMAT_STRING;


static RPC_SYNTAX_IDENTIFIER  _RpcTransferSyntax = 
{{0x8A885D04,0x1CEB,0x11C9,{0x9F,0xE8,0x08,0x00,0x2B,0x10,0x48,0x60}},{2,0}};


extern const MIDL_TYPE_FORMAT_STRING __MIDL_TypeFormatString;
extern const MIDL_PROC_FORMAT_STRING __MIDL_ProcFormatString;


extern const MIDL_STUB_DESC Object_StubDesc;


extern const MIDL_SERVER_INFO ICardProcess_ServerInfo;
extern const MIDL_STUBLESS_PROXY_INFO ICardProcess_ProxyInfo;


extern const USER_MARSHAL_ROUTINE_QUADRUPLE UserMarshalRoutines[ WIRE_MARSHAL_TABLE_SIZE ];

#if !defined(__RPC_WIN32__)
#error  Invalid build platform for this stub.
#endif

#if !(TARGET_IS_NT40_OR_LATER)
#error You need a Windows NT 4.0 or later to run this stub because it uses these features:
#error   -Oif or -Oicf, [wire_marshal] or [user_marshal] attribute, more than 32 methods in the interface.
#error However, your C/C++ compilation flags indicate you intend to run this app on earlier systems.
#error This app will die there with the RPC_X_WRONG_STUB_VERSION error.
#endif


static const MIDL_PROC_FORMAT_STRING __MIDL_ProcFormatString =
    {
        0,
        {

	/* Procedure iATLGetCardVersion */

			0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/*  2 */	NdrFcLong( 0x0 ),	/* 0 */
/*  6 */	NdrFcShort( 0x7 ),	/* 7 */
/*  8 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 10 */	NdrFcShort( 0x0 ),	/* 0 */
/* 12 */	NdrFcShort( 0x8 ),	/* 8 */
/* 14 */	0x5,		/* Oi2 Flags:  srv must size, has return, */
			0x2,		/* 2 */

	/* Parameter szVersion */

/* 16 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 18 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 20 */	NdrFcShort( 0x1e ),	/* Type Offset=30 */

	/* Return value */

/* 22 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 24 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 26 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure iATLCardInit */

/* 28 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 30 */	NdrFcLong( 0x0 ),	/* 0 */
/* 34 */	NdrFcShort( 0x8 ),	/* 8 */
/* 36 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 38 */	NdrFcShort( 0x0 ),	/* 0 */
/* 40 */	NdrFcShort( 0x24 ),	/* 36 */
/* 42 */	0x4,		/* Oi2 Flags:  has return, */
			0x2,		/* 2 */

	/* Parameter nRet */

/* 44 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 46 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 48 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 50 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 52 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 54 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure iATLReadInfo */

/* 56 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 58 */	NdrFcLong( 0x0 ),	/* 0 */
/* 62 */	NdrFcShort( 0x9 ),	/* 9 */
/* 64 */	NdrFcShort( 0x10 ),	/* x86 Stack size/offset = 16 */
/* 66 */	NdrFcShort( 0x8 ),	/* 8 */
/* 68 */	NdrFcShort( 0x8 ),	/* 8 */
/* 70 */	0x5,		/* Oi2 Flags:  srv must size, has return, */
			0x3,		/* 3 */

	/* Parameter nFlag */

/* 72 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 74 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 76 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter szReadXML */

/* 78 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 80 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 82 */	NdrFcShort( 0x1e ),	/* Type Offset=30 */

	/* Return value */

/* 84 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 86 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 88 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure iATLWriteInfo */

/* 90 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 92 */	NdrFcLong( 0x0 ),	/* 0 */
/* 96 */	NdrFcShort( 0xa ),	/* 10 */
/* 98 */	NdrFcShort( 0x10 ),	/* x86 Stack size/offset = 16 */
/* 100 */	NdrFcShort( 0x0 ),	/* 0 */
/* 102 */	NdrFcShort( 0x24 ),	/* 36 */
/* 104 */	0x6,		/* Oi2 Flags:  clt must size, has return, */
			0x3,		/* 3 */

	/* Parameter szXML */

/* 106 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 108 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 110 */	NdrFcShort( 0x30 ),	/* Type Offset=48 */

	/* Parameter nRet */

/* 112 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 114 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 116 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 118 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 120 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 122 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure iATLQueryInfo */

/* 124 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 126 */	NdrFcLong( 0x0 ),	/* 0 */
/* 130 */	NdrFcShort( 0xb ),	/* 11 */
/* 132 */	NdrFcShort( 0x10 ),	/* x86 Stack size/offset = 16 */
/* 134 */	NdrFcShort( 0x0 ),	/* 0 */
/* 136 */	NdrFcShort( 0x8 ),	/* 8 */
/* 138 */	0x7,		/* Oi2 Flags:  srv must size, clt must size, has return, */
			0x3,		/* 3 */

	/* Parameter szQuerySource */

/* 140 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 142 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 144 */	NdrFcShort( 0x30 ),	/* Type Offset=48 */

	/* Parameter szResult */

/* 146 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 148 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 150 */	NdrFcShort( 0x1e ),	/* Type Offset=30 */

	/* Return value */

/* 152 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 154 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 156 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure iATLerr */

/* 158 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 160 */	NdrFcLong( 0x0 ),	/* 0 */
/* 164 */	NdrFcShort( 0xc ),	/* 12 */
/* 166 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 168 */	NdrFcShort( 0x0 ),	/* 0 */
/* 170 */	NdrFcShort( 0x8 ),	/* 8 */
/* 172 */	0x5,		/* Oi2 Flags:  srv must size, has return, */
			0x2,		/* 2 */

	/* Parameter szError */

/* 174 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 176 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 178 */	NdrFcShort( 0x1e ),	/* Type Offset=30 */

	/* Return value */

/* 180 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 182 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 184 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure iATLFormatCard */

/* 186 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 188 */	NdrFcLong( 0x0 ),	/* 0 */
/* 192 */	NdrFcShort( 0xd ),	/* 13 */
/* 194 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 196 */	NdrFcShort( 0x0 ),	/* 0 */
/* 198 */	NdrFcShort( 0x24 ),	/* 36 */
/* 200 */	0x4,		/* Oi2 Flags:  has return, */
			0x2,		/* 2 */

	/* Parameter nRet */

/* 202 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 204 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 206 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 208 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 210 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 212 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure iATLCreateCard */

/* 214 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 216 */	NdrFcLong( 0x0 ),	/* 0 */
/* 220 */	NdrFcShort( 0xe ),	/* 14 */
/* 222 */	NdrFcShort( 0x10 ),	/* x86 Stack size/offset = 16 */
/* 224 */	NdrFcShort( 0x0 ),	/* 0 */
/* 226 */	NdrFcShort( 0x24 ),	/* 36 */
/* 228 */	0x6,		/* Oi2 Flags:  clt must size, has return, */
			0x3,		/* 3 */

	/* Parameter szCardXML */

/* 230 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 232 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 234 */	NdrFcShort( 0x30 ),	/* Type Offset=48 */

	/* Parameter nRet */

/* 236 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 238 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 240 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 242 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 244 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 246 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure iATLPrintCard */

/* 248 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 250 */	NdrFcLong( 0x0 ),	/* 0 */
/* 254 */	NdrFcShort( 0xf ),	/* 15 */
/* 256 */	NdrFcShort( 0x18 ),	/* x86 Stack size/offset = 24 */
/* 258 */	NdrFcShort( 0x0 ),	/* 0 */
/* 260 */	NdrFcShort( 0x24 ),	/* 36 */
/* 262 */	0x6,		/* Oi2 Flags:  clt must size, has return, */
			0x5,		/* 5 */

	/* Parameter pszPrinterType */

/* 264 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 266 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 268 */	NdrFcShort( 0x30 ),	/* Type Offset=48 */

	/* Parameter pszCardCoverDataXml */

/* 270 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 272 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 274 */	NdrFcShort( 0x30 ),	/* Type Offset=48 */

	/* Parameter pszCardCoverXml */

/* 276 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 278 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 280 */	NdrFcShort( 0x30 ),	/* Type Offset=48 */

	/* Parameter nRet */

/* 282 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 284 */	NdrFcShort( 0x10 ),	/* x86 Stack size/offset = 16 */
/* 286 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 288 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 290 */	NdrFcShort( 0x14 ),	/* x86 Stack size/offset = 20 */
/* 292 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure iATLPatchCard */

/* 294 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 296 */	NdrFcLong( 0x0 ),	/* 0 */
/* 300 */	NdrFcShort( 0x10 ),	/* 16 */
/* 302 */	NdrFcShort( 0x1c ),	/* x86 Stack size/offset = 28 */
/* 304 */	NdrFcShort( 0x0 ),	/* 0 */
/* 306 */	NdrFcShort( 0x24 ),	/* 36 */
/* 308 */	0x6,		/* Oi2 Flags:  clt must size, has return, */
			0x6,		/* 6 */

	/* Parameter szCardXML */

/* 310 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 312 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 314 */	NdrFcShort( 0x30 ),	/* Type Offset=48 */

	/* Parameter pszCardCoverDataXml */

/* 316 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 318 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 320 */	NdrFcShort( 0x30 ),	/* Type Offset=48 */

	/* Parameter pszPrinterType */

/* 322 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 324 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 326 */	NdrFcShort( 0x30 ),	/* Type Offset=48 */

	/* Parameter pszCardCoverXml */

/* 328 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 330 */	NdrFcShort( 0x10 ),	/* x86 Stack size/offset = 16 */
/* 332 */	NdrFcShort( 0x30 ),	/* Type Offset=48 */

	/* Parameter nRet */

/* 334 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 336 */	NdrFcShort( 0x14 ),	/* x86 Stack size/offset = 20 */
/* 338 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 340 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 342 */	NdrFcShort( 0x18 ),	/* x86 Stack size/offset = 24 */
/* 344 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure iATLCreateCardData */

/* 346 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 348 */	NdrFcLong( 0x0 ),	/* 0 */
/* 352 */	NdrFcShort( 0x11 ),	/* 17 */
/* 354 */	NdrFcShort( 0x10 ),	/* x86 Stack size/offset = 16 */
/* 356 */	NdrFcShort( 0x0 ),	/* 0 */
/* 358 */	NdrFcShort( 0x8 ),	/* 8 */
/* 360 */	0x6,		/* Oi2 Flags:  clt must size, has return, */
			0x3,		/* 3 */

	/* Parameter szCreateData */

/* 362 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 364 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 366 */	NdrFcShort( 0x30 ),	/* Type Offset=48 */

	/* Parameter szLicense */

/* 368 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 370 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 372 */	NdrFcShort( 0x30 ),	/* Type Offset=48 */

	/* Return value */

/* 374 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 376 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 378 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure iATLScanCard */

/* 380 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 382 */	NdrFcLong( 0x0 ),	/* 0 */
/* 386 */	NdrFcShort( 0x12 ),	/* 18 */
/* 388 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 390 */	NdrFcShort( 0x0 ),	/* 0 */
/* 392 */	NdrFcShort( 0x24 ),	/* 36 */
/* 394 */	0x4,		/* Oi2 Flags:  has return, */
			0x2,		/* 2 */

	/* Parameter nRet */

/* 396 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 398 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 400 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 402 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 404 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 406 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure iATLCardClose */

/* 408 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 410 */	NdrFcLong( 0x0 ),	/* 0 */
/* 414 */	NdrFcShort( 0x13 ),	/* 19 */
/* 416 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 418 */	NdrFcShort( 0x0 ),	/* 0 */
/* 420 */	NdrFcShort( 0x24 ),	/* 36 */
/* 422 */	0x4,		/* Oi2 Flags:  has return, */
			0x2,		/* 2 */

	/* Parameter nRet */

/* 424 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 426 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 428 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 430 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 432 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 434 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure iATLReadCardMessageForNH */

/* 436 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 438 */	NdrFcLong( 0x0 ),	/* 0 */
/* 442 */	NdrFcShort( 0x14 ),	/* 20 */
/* 444 */	NdrFcShort( 0x14 ),	/* x86 Stack size/offset = 20 */
/* 446 */	NdrFcShort( 0x0 ),	/* 0 */
/* 448 */	NdrFcShort( 0x8 ),	/* 8 */
/* 450 */	0x7,		/* Oi2 Flags:  srv must size, clt must size, has return, */
			0x4,		/* 4 */

	/* Parameter pszCardCheckXML */

/* 452 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 454 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 456 */	NdrFcShort( 0x30 ),	/* Type Offset=48 */

	/* Parameter pszCardRewritePackageXML */

/* 458 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 460 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 462 */	NdrFcShort( 0x30 ),	/* Type Offset=48 */

	/* Parameter pszXml */

/* 464 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 466 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 468 */	NdrFcShort( 0x1e ),	/* Type Offset=30 */

	/* Return value */

/* 470 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 472 */	NdrFcShort( 0x10 ),	/* x86 Stack size/offset = 16 */
/* 474 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure iATLReadHISInfo */

/* 476 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 478 */	NdrFcLong( 0x0 ),	/* 0 */
/* 482 */	NdrFcShort( 0x15 ),	/* 21 */
/* 484 */	NdrFcShort( 0x14 ),	/* x86 Stack size/offset = 20 */
/* 486 */	NdrFcShort( 0x0 ),	/* 0 */
/* 488 */	NdrFcShort( 0x8 ),	/* 8 */
/* 490 */	0x7,		/* Oi2 Flags:  srv must size, clt must size, has return, */
			0x4,		/* 4 */

	/* Parameter pszCardCheckXML */

/* 492 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 494 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 496 */	NdrFcShort( 0x30 ),	/* Type Offset=48 */

	/* Parameter pszCardRewritePackageXML */

/* 498 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 500 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 502 */	NdrFcShort( 0x30 ),	/* Type Offset=48 */

	/* Parameter szXML */

/* 504 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 506 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 508 */	NdrFcShort( 0x1e ),	/* Type Offset=30 */

	/* Return value */

/* 510 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 512 */	NdrFcShort( 0x10 ),	/* x86 Stack size/offset = 16 */
/* 514 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure iATLReadInfoForXJ */

/* 516 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 518 */	NdrFcLong( 0x0 ),	/* 0 */
/* 522 */	NdrFcShort( 0x16 ),	/* 22 */
/* 524 */	NdrFcShort( 0x14 ),	/* x86 Stack size/offset = 20 */
/* 526 */	NdrFcShort( 0x0 ),	/* 0 */
/* 528 */	NdrFcShort( 0x8 ),	/* 8 */
/* 530 */	0x7,		/* Oi2 Flags:  srv must size, clt must size, has return, */
			0x4,		/* 4 */

	/* Parameter pszCardCheckXML */

/* 532 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 534 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 536 */	NdrFcShort( 0x30 ),	/* Type Offset=48 */

	/* Parameter pszCardRewritePackageXML */

/* 538 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 540 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 542 */	NdrFcShort( 0x30 ),	/* Type Offset=48 */

	/* Parameter szXML */

/* 544 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 546 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 548 */	NdrFcShort( 0x1e ),	/* Type Offset=30 */

	/* Return value */

/* 550 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 552 */	NdrFcShort( 0x10 ),	/* x86 Stack size/offset = 16 */
/* 554 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure iATLCardIsEmpty */

/* 556 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 558 */	NdrFcLong( 0x0 ),	/* 0 */
/* 562 */	NdrFcShort( 0x17 ),	/* 23 */
/* 564 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 566 */	NdrFcShort( 0x0 ),	/* 0 */
/* 568 */	NdrFcShort( 0x24 ),	/* 36 */
/* 570 */	0x4,		/* Oi2 Flags:  has return, */
			0x2,		/* 2 */

	/* Parameter bEmpty */

/* 572 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 574 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 576 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 578 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 580 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 582 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure iATLCheckMsgForNH */

/* 584 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 586 */	NdrFcLong( 0x0 ),	/* 0 */
/* 590 */	NdrFcShort( 0x18 ),	/* 24 */
/* 592 */	NdrFcShort( 0x14 ),	/* x86 Stack size/offset = 20 */
/* 594 */	NdrFcShort( 0x0 ),	/* 0 */
/* 596 */	NdrFcShort( 0x8 ),	/* 8 */
/* 598 */	0x7,		/* Oi2 Flags:  srv must size, clt must size, has return, */
			0x4,		/* 4 */

	/* Parameter bstrCheckWSDL */

/* 600 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 602 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 604 */	NdrFcShort( 0x30 ),	/* Type Offset=48 */

	/* Parameter bstrServerURL */

/* 606 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 608 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 610 */	NdrFcShort( 0x30 ),	/* Type Offset=48 */

	/* Parameter strCheckRet */

/* 612 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 614 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 616 */	NdrFcShort( 0x1e ),	/* Type Offset=30 */

	/* Return value */

/* 618 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 620 */	NdrFcShort( 0x10 ),	/* x86 Stack size/offset = 16 */
/* 622 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure iATLReadConfigMsg */

/* 624 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 626 */	NdrFcLong( 0x0 ),	/* 0 */
/* 630 */	NdrFcShort( 0x19 ),	/* 25 */
/* 632 */	NdrFcShort( 0x10 ),	/* x86 Stack size/offset = 16 */
/* 634 */	NdrFcShort( 0x0 ),	/* 0 */
/* 636 */	NdrFcShort( 0x8 ),	/* 8 */
/* 638 */	0x7,		/* Oi2 Flags:  srv must size, clt must size, has return, */
			0x3,		/* 3 */

	/* Parameter bstrConfigInfo */

/* 640 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 642 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 644 */	NdrFcShort( 0x30 ),	/* Type Offset=48 */

	/* Parameter bstrReadXML */

/* 646 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 648 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 650 */	NdrFcShort( 0x1e ),	/* Type Offset=30 */

	/* Return value */

/* 652 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 654 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 656 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure iATLRegMsgForNH */

/* 658 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 660 */	NdrFcLong( 0x0 ),	/* 0 */
/* 664 */	NdrFcShort( 0x1a ),	/* 26 */
/* 666 */	NdrFcShort( 0x10 ),	/* x86 Stack size/offset = 16 */
/* 668 */	NdrFcShort( 0x0 ),	/* 0 */
/* 670 */	NdrFcShort( 0x8 ),	/* 8 */
/* 672 */	0x7,		/* Oi2 Flags:  srv must size, clt must size, has return, */
			0x3,		/* 3 */

	/* Parameter bstrServerURL */

/* 674 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 676 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 678 */	NdrFcShort( 0x30 ),	/* Type Offset=48 */

	/* Parameter bstrReadXML */

/* 680 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 682 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 684 */	NdrFcShort( 0x1e ),	/* Type Offset=30 */

	/* Return value */

/* 686 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 688 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 690 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure iATLEncryFile */

/* 692 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 694 */	NdrFcLong( 0x0 ),	/* 0 */
/* 698 */	NdrFcShort( 0x1b ),	/* 27 */
/* 700 */	NdrFcShort( 0x10 ),	/* x86 Stack size/offset = 16 */
/* 702 */	NdrFcShort( 0x0 ),	/* 0 */
/* 704 */	NdrFcShort( 0x24 ),	/* 36 */
/* 706 */	0x6,		/* Oi2 Flags:  clt must size, has return, */
			0x3,		/* 3 */

	/* Parameter bstrfilename */

/* 708 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 710 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 712 */	NdrFcShort( 0x30 ),	/* Type Offset=48 */

	/* Parameter nProCode */

/* 714 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 716 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 718 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 720 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 722 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 724 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure iATLGetPrinterList */

/* 726 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 728 */	NdrFcLong( 0x0 ),	/* 0 */
/* 732 */	NdrFcShort( 0x1c ),	/* 28 */
/* 734 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 736 */	NdrFcShort( 0x0 ),	/* 0 */
/* 738 */	NdrFcShort( 0x8 ),	/* 8 */
/* 740 */	0x5,		/* Oi2 Flags:  srv must size, has return, */
			0x2,		/* 2 */

	/* Parameter bstrPrinterXML */

/* 742 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 744 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 746 */	NdrFcShort( 0x1e ),	/* Type Offset=30 */

	/* Return value */

/* 748 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 750 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 752 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure iATLReadOnlyHIS */

/* 754 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 756 */	NdrFcLong( 0x0 ),	/* 0 */
/* 760 */	NdrFcShort( 0x1d ),	/* 29 */
/* 762 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 764 */	NdrFcShort( 0x0 ),	/* 0 */
/* 766 */	NdrFcShort( 0x8 ),	/* 8 */
/* 768 */	0x5,		/* Oi2 Flags:  srv must size, has return, */
			0x2,		/* 2 */

	/* Parameter bstrHISInfo */

/* 770 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 772 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 774 */	NdrFcShort( 0x1e ),	/* Type Offset=30 */

	/* Return value */

/* 776 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 778 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 780 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure iATLCardOpen */

/* 782 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 784 */	NdrFcLong( 0x0 ),	/* 0 */
/* 788 */	NdrFcShort( 0x1e ),	/* 30 */
/* 790 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 792 */	NdrFcShort( 0x0 ),	/* 0 */
/* 794 */	NdrFcShort( 0x24 ),	/* 36 */
/* 796 */	0x4,		/* Oi2 Flags:  has return, */
			0x2,		/* 2 */

	/* Parameter Ret */

/* 798 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 800 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 802 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 804 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 806 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 808 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure iATLCardDeinit */

/* 810 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 812 */	NdrFcLong( 0x0 ),	/* 0 */
/* 816 */	NdrFcShort( 0x1f ),	/* 31 */
/* 818 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 820 */	NdrFcShort( 0x0 ),	/* 0 */
/* 822 */	NdrFcShort( 0x24 ),	/* 36 */
/* 824 */	0x4,		/* Oi2 Flags:  has return, */
			0x2,		/* 2 */

	/* Parameter Ret */

/* 826 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 828 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 830 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 832 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 834 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 836 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure iATLCreateLicense */

/* 838 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 840 */	NdrFcLong( 0x0 ),	/* 0 */
/* 844 */	NdrFcShort( 0x20 ),	/* 32 */
/* 846 */	NdrFcShort( 0x10 ),	/* x86 Stack size/offset = 16 */
/* 848 */	NdrFcShort( 0x1c ),	/* 28 */
/* 850 */	NdrFcShort( 0x8 ),	/* 8 */
/* 852 */	0x6,		/* Oi2 Flags:  clt must size, has return, */
			0x3,		/* 3 */

	/* Parameter timeFMT */

/* 854 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 856 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 858 */	NdrFcShort( 0x30 ),	/* Type Offset=48 */

	/* Parameter ret */

/* 860 */	NdrFcShort( 0x148 ),	/* Flags:  in, base type, simple ref, */
/* 862 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 864 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 866 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 868 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 870 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure iATLFormatHospInfo */

/* 872 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 874 */	NdrFcLong( 0x0 ),	/* 0 */
/* 878 */	NdrFcShort( 0x21 ),	/* 33 */
/* 880 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 882 */	NdrFcShort( 0x0 ),	/* 0 */
/* 884 */	NdrFcShort( 0x24 ),	/* 36 */
/* 886 */	0x4,		/* Oi2 Flags:  has return, */
			0x2,		/* 2 */

	/* Parameter pRet */

/* 888 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 890 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 892 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 894 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 896 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 898 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure iATLWriteHospInfo */

/* 900 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 902 */	NdrFcLong( 0x0 ),	/* 0 */
/* 906 */	NdrFcShort( 0x22 ),	/* 34 */
/* 908 */	NdrFcShort( 0x10 ),	/* x86 Stack size/offset = 16 */
/* 910 */	NdrFcShort( 0x0 ),	/* 0 */
/* 912 */	NdrFcShort( 0x24 ),	/* 36 */
/* 914 */	0x6,		/* Oi2 Flags:  clt must size, has return, */
			0x3,		/* 3 */

	/* Parameter xml */

/* 916 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 918 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 920 */	NdrFcShort( 0x30 ),	/* Type Offset=48 */

	/* Parameter pRet */

/* 922 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 924 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 926 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 928 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 930 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 932 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure iATLReadClinicInfo */

/* 934 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 936 */	NdrFcLong( 0x0 ),	/* 0 */
/* 940 */	NdrFcShort( 0x23 ),	/* 35 */
/* 942 */	NdrFcShort( 0x10 ),	/* x86 Stack size/offset = 16 */
/* 944 */	NdrFcShort( 0x0 ),	/* 0 */
/* 946 */	NdrFcShort( 0x8 ),	/* 8 */
/* 948 */	0x7,		/* Oi2 Flags:  srv must size, clt must size, has return, */
			0x3,		/* 3 */

	/* Parameter pszCode */

/* 950 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 952 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 954 */	NdrFcShort( 0x30 ),	/* Type Offset=48 */

	/* Parameter readXML */

/* 956 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 958 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 960 */	NdrFcShort( 0x1e ),	/* Type Offset=30 */

	/* Return value */

/* 962 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 964 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 966 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure iATLReadMedicalInfo */

/* 968 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 970 */	NdrFcLong( 0x0 ),	/* 0 */
/* 974 */	NdrFcShort( 0x24 ),	/* 36 */
/* 976 */	NdrFcShort( 0x10 ),	/* x86 Stack size/offset = 16 */
/* 978 */	NdrFcShort( 0x0 ),	/* 0 */
/* 980 */	NdrFcShort( 0x8 ),	/* 8 */
/* 982 */	0x7,		/* Oi2 Flags:  srv must size, clt must size, has return, */
			0x3,		/* 3 */

	/* Parameter pszCode */

/* 984 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 986 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 988 */	NdrFcShort( 0x30 ),	/* Type Offset=48 */

	/* Parameter readXML */

/* 990 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 992 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 994 */	NdrFcShort( 0x1e ),	/* Type Offset=30 */

	/* Return value */

/* 996 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 998 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 1000 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure iATLReadFeeInfo */

/* 1002 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 1004 */	NdrFcLong( 0x0 ),	/* 0 */
/* 1008 */	NdrFcShort( 0x25 ),	/* 37 */
/* 1010 */	NdrFcShort( 0x10 ),	/* x86 Stack size/offset = 16 */
/* 1012 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1014 */	NdrFcShort( 0x8 ),	/* 8 */
/* 1016 */	0x7,		/* Oi2 Flags:  srv must size, clt must size, has return, */
			0x3,		/* 3 */

	/* Parameter pszCode */

/* 1018 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 1020 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 1022 */	NdrFcShort( 0x30 ),	/* Type Offset=48 */

	/* Parameter readXML */

/* 1024 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 1026 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 1028 */	NdrFcShort( 0x1e ),	/* Type Offset=30 */

	/* Return value */

/* 1030 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 1032 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 1034 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure iATLReadOnlyHISLog */

/* 1036 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 1038 */	NdrFcLong( 0x0 ),	/* 0 */
/* 1042 */	NdrFcShort( 0x26 ),	/* 38 */
/* 1044 */	NdrFcShort( 0x10 ),	/* x86 Stack size/offset = 16 */
/* 1046 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1048 */	NdrFcShort( 0x8 ),	/* 8 */
/* 1050 */	0x7,		/* Oi2 Flags:  srv must size, clt must size, has return, */
			0x3,		/* 3 */

	/* Parameter logConfXml */

/* 1052 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 1054 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 1056 */	NdrFcShort( 0x30 ),	/* Type Offset=48 */

	/* Parameter bstrHISInfo */

/* 1058 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 1060 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 1062 */	NdrFcShort( 0x1e ),	/* Type Offset=30 */

	/* Return value */

/* 1064 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 1066 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 1068 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure iATLReadInfoForXJLog */

/* 1070 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 1072 */	NdrFcLong( 0x0 ),	/* 0 */
/* 1076 */	NdrFcShort( 0x27 ),	/* 39 */
/* 1078 */	NdrFcShort( 0x18 ),	/* x86 Stack size/offset = 24 */
/* 1080 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1082 */	NdrFcShort( 0x8 ),	/* 8 */
/* 1084 */	0x7,		/* Oi2 Flags:  srv must size, clt must size, has return, */
			0x5,		/* 5 */

	/* Parameter pszCardCheckWSDL */

/* 1086 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 1088 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 1090 */	NdrFcShort( 0x30 ),	/* Type Offset=48 */

	/* Parameter pszCardServerURL */

/* 1092 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 1094 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 1096 */	NdrFcShort( 0x30 ),	/* Type Offset=48 */

	/* Parameter pszLogXml */

/* 1098 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 1100 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 1102 */	NdrFcShort( 0x30 ),	/* Type Offset=48 */

	/* Parameter xml */

/* 1104 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 1106 */	NdrFcShort( 0x10 ),	/* x86 Stack size/offset = 16 */
/* 1108 */	NdrFcShort( 0x1e ),	/* Type Offset=30 */

	/* Return value */

/* 1110 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 1112 */	NdrFcShort( 0x14 ),	/* x86 Stack size/offset = 20 */
/* 1114 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure iATLReadHISInfoLog */

/* 1116 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 1118 */	NdrFcLong( 0x0 ),	/* 0 */
/* 1122 */	NdrFcShort( 0x28 ),	/* 40 */
/* 1124 */	NdrFcShort( 0x18 ),	/* x86 Stack size/offset = 24 */
/* 1126 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1128 */	NdrFcShort( 0x8 ),	/* 8 */
/* 1130 */	0x7,		/* Oi2 Flags:  srv must size, clt must size, has return, */
			0x5,		/* 5 */

	/* Parameter pszCardCheckWSDL */

/* 1132 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 1134 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 1136 */	NdrFcShort( 0x30 ),	/* Type Offset=48 */

	/* Parameter pszCardServerURL */

/* 1138 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 1140 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 1142 */	NdrFcShort( 0x30 ),	/* Type Offset=48 */

	/* Parameter pszLogXml */

/* 1144 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 1146 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 1148 */	NdrFcShort( 0x30 ),	/* Type Offset=48 */

	/* Parameter xml */

/* 1150 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 1152 */	NdrFcShort( 0x10 ),	/* x86 Stack size/offset = 16 */
/* 1154 */	NdrFcShort( 0x1e ),	/* Type Offset=30 */

	/* Return value */

/* 1156 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 1158 */	NdrFcShort( 0x14 ),	/* x86 Stack size/offset = 20 */
/* 1160 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure iATLReadMedicalInfoLog */

/* 1162 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 1164 */	NdrFcLong( 0x0 ),	/* 0 */
/* 1168 */	NdrFcShort( 0x29 ),	/* 41 */
/* 1170 */	NdrFcShort( 0x14 ),	/* x86 Stack size/offset = 20 */
/* 1172 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1174 */	NdrFcShort( 0x8 ),	/* 8 */
/* 1176 */	0x7,		/* Oi2 Flags:  srv must size, clt must size, has return, */
			0x4,		/* 4 */

	/* Parameter pszCode */

/* 1178 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 1180 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 1182 */	NdrFcShort( 0x30 ),	/* Type Offset=48 */

	/* Parameter pszLogXml */

/* 1184 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 1186 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 1188 */	NdrFcShort( 0x30 ),	/* Type Offset=48 */

	/* Parameter xml */

/* 1190 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 1192 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 1194 */	NdrFcShort( 0x1e ),	/* Type Offset=30 */

	/* Return value */

/* 1196 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 1198 */	NdrFcShort( 0x10 ),	/* x86 Stack size/offset = 16 */
/* 1200 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure iATLReadFeeInfoLog */

/* 1202 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 1204 */	NdrFcLong( 0x0 ),	/* 0 */
/* 1208 */	NdrFcShort( 0x2a ),	/* 42 */
/* 1210 */	NdrFcShort( 0x14 ),	/* x86 Stack size/offset = 20 */
/* 1212 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1214 */	NdrFcShort( 0x8 ),	/* 8 */
/* 1216 */	0x7,		/* Oi2 Flags:  srv must size, clt must size, has return, */
			0x4,		/* 4 */

	/* Parameter pszCode */

/* 1218 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 1220 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 1222 */	NdrFcShort( 0x30 ),	/* Type Offset=48 */

	/* Parameter pszLogXml */

/* 1224 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 1226 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 1228 */	NdrFcShort( 0x30 ),	/* Type Offset=48 */

	/* Parameter xml */

/* 1230 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 1232 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 1234 */	NdrFcShort( 0x1e ),	/* Type Offset=30 */

	/* Return value */

/* 1236 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 1238 */	NdrFcShort( 0x10 ),	/* x86 Stack size/offset = 16 */
/* 1240 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure iATLWriteHospInfoLog */

/* 1242 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 1244 */	NdrFcLong( 0x0 ),	/* 0 */
/* 1248 */	NdrFcShort( 0x2b ),	/* 43 */
/* 1250 */	NdrFcShort( 0x14 ),	/* x86 Stack size/offset = 20 */
/* 1252 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1254 */	NdrFcShort( 0x24 ),	/* 36 */
/* 1256 */	0x6,		/* Oi2 Flags:  clt must size, has return, */
			0x4,		/* 4 */

	/* Parameter xml */

/* 1258 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 1260 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 1262 */	NdrFcShort( 0x30 ),	/* Type Offset=48 */

	/* Parameter pszLogXml */

/* 1264 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 1266 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 1268 */	NdrFcShort( 0x30 ),	/* Type Offset=48 */

	/* Parameter pRet */

/* 1270 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 1272 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 1274 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 1276 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 1278 */	NdrFcShort( 0x10 ),	/* x86 Stack size/offset = 16 */
/* 1280 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure iATLReadClinicInfoLog */

/* 1282 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 1284 */	NdrFcLong( 0x0 ),	/* 0 */
/* 1288 */	NdrFcShort( 0x2c ),	/* 44 */
/* 1290 */	NdrFcShort( 0x14 ),	/* x86 Stack size/offset = 20 */
/* 1292 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1294 */	NdrFcShort( 0x8 ),	/* 8 */
/* 1296 */	0x7,		/* Oi2 Flags:  srv must size, clt must size, has return, */
			0x4,		/* 4 */

	/* Parameter pszCode */

/* 1298 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 1300 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 1302 */	NdrFcShort( 0x30 ),	/* Type Offset=48 */

	/* Parameter pszLogXml */

/* 1304 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 1306 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 1308 */	NdrFcShort( 0x30 ),	/* Type Offset=48 */

	/* Parameter xml */

/* 1310 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 1312 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 1314 */	NdrFcShort( 0x1e ),	/* Type Offset=30 */

	/* Return value */

/* 1316 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 1318 */	NdrFcShort( 0x10 ),	/* x86 Stack size/offset = 16 */
/* 1320 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure iATLReadOnlyHISLocal */

/* 1322 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 1324 */	NdrFcLong( 0x0 ),	/* 0 */
/* 1328 */	NdrFcShort( 0x2d ),	/* 45 */
/* 1330 */	NdrFcShort( 0x10 ),	/* x86 Stack size/offset = 16 */
/* 1332 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1334 */	NdrFcShort( 0x8 ),	/* 8 */
/* 1336 */	0x7,		/* Oi2 Flags:  srv must size, clt must size, has return, */
			0x3,		/* 3 */

	/* Parameter pszLogXml */

/* 1338 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 1340 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 1342 */	NdrFcShort( 0x30 ),	/* Type Offset=48 */

	/* Parameter xml */

/* 1344 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 1346 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 1348 */	NdrFcShort( 0x1e ),	/* Type Offset=30 */

	/* Return value */

/* 1350 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 1352 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 1354 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure iATLReadInfoForXJLocal */

/* 1356 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 1358 */	NdrFcLong( 0x0 ),	/* 0 */
/* 1362 */	NdrFcShort( 0x2e ),	/* 46 */
/* 1364 */	NdrFcShort( 0x18 ),	/* x86 Stack size/offset = 24 */
/* 1366 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1368 */	NdrFcShort( 0x8 ),	/* 8 */
/* 1370 */	0x7,		/* Oi2 Flags:  srv must size, clt must size, has return, */
			0x5,		/* 5 */

	/* Parameter pszCardCheckWSDL */

/* 1372 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 1374 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 1376 */	NdrFcShort( 0x30 ),	/* Type Offset=48 */

	/* Parameter pszCardServerURL */

/* 1378 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 1380 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 1382 */	NdrFcShort( 0x30 ),	/* Type Offset=48 */

	/* Parameter pszLogXml */

/* 1384 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 1386 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 1388 */	NdrFcShort( 0x30 ),	/* Type Offset=48 */

	/* Parameter xml */

/* 1390 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 1392 */	NdrFcShort( 0x10 ),	/* x86 Stack size/offset = 16 */
/* 1394 */	NdrFcShort( 0x1e ),	/* Type Offset=30 */

	/* Return value */

/* 1396 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 1398 */	NdrFcShort( 0x14 ),	/* x86 Stack size/offset = 20 */
/* 1400 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure iATLReadHISInfoLocal */

/* 1402 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 1404 */	NdrFcLong( 0x0 ),	/* 0 */
/* 1408 */	NdrFcShort( 0x2f ),	/* 47 */
/* 1410 */	NdrFcShort( 0x18 ),	/* x86 Stack size/offset = 24 */
/* 1412 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1414 */	NdrFcShort( 0x8 ),	/* 8 */
/* 1416 */	0x7,		/* Oi2 Flags:  srv must size, clt must size, has return, */
			0x5,		/* 5 */

	/* Parameter pszCardCheckWSDL */

/* 1418 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 1420 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 1422 */	NdrFcShort( 0x30 ),	/* Type Offset=48 */

	/* Parameter pszCardServerURL */

/* 1424 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 1426 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 1428 */	NdrFcShort( 0x30 ),	/* Type Offset=48 */

	/* Parameter pszLogXml */

/* 1430 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 1432 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 1434 */	NdrFcShort( 0x30 ),	/* Type Offset=48 */

	/* Parameter xml */

/* 1436 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 1438 */	NdrFcShort( 0x10 ),	/* x86 Stack size/offset = 16 */
/* 1440 */	NdrFcShort( 0x1e ),	/* Type Offset=30 */

	/* Return value */

/* 1442 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 1444 */	NdrFcShort( 0x14 ),	/* x86 Stack size/offset = 20 */
/* 1446 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure iATLReadMedicalInfoLocal */

/* 1448 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 1450 */	NdrFcLong( 0x0 ),	/* 0 */
/* 1454 */	NdrFcShort( 0x30 ),	/* 48 */
/* 1456 */	NdrFcShort( 0x14 ),	/* x86 Stack size/offset = 20 */
/* 1458 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1460 */	NdrFcShort( 0x8 ),	/* 8 */
/* 1462 */	0x7,		/* Oi2 Flags:  srv must size, clt must size, has return, */
			0x4,		/* 4 */

	/* Parameter pszCode */

/* 1464 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 1466 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 1468 */	NdrFcShort( 0x30 ),	/* Type Offset=48 */

	/* Parameter pszLogXml */

/* 1470 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 1472 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 1474 */	NdrFcShort( 0x30 ),	/* Type Offset=48 */

	/* Parameter xml */

/* 1476 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 1478 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 1480 */	NdrFcShort( 0x1e ),	/* Type Offset=30 */

	/* Return value */

/* 1482 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 1484 */	NdrFcShort( 0x10 ),	/* x86 Stack size/offset = 16 */
/* 1486 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure iATLReadFeeInfoLocal */

/* 1488 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 1490 */	NdrFcLong( 0x0 ),	/* 0 */
/* 1494 */	NdrFcShort( 0x31 ),	/* 49 */
/* 1496 */	NdrFcShort( 0x14 ),	/* x86 Stack size/offset = 20 */
/* 1498 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1500 */	NdrFcShort( 0x8 ),	/* 8 */
/* 1502 */	0x7,		/* Oi2 Flags:  srv must size, clt must size, has return, */
			0x4,		/* 4 */

	/* Parameter pszCode */

/* 1504 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 1506 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 1508 */	NdrFcShort( 0x30 ),	/* Type Offset=48 */

	/* Parameter pszLogXml */

/* 1510 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 1512 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 1514 */	NdrFcShort( 0x30 ),	/* Type Offset=48 */

	/* Parameter xml */

/* 1516 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 1518 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 1520 */	NdrFcShort( 0x1e ),	/* Type Offset=30 */

	/* Return value */

/* 1522 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 1524 */	NdrFcShort( 0x10 ),	/* x86 Stack size/offset = 16 */
/* 1526 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure iATLReadClinicInfoLocal */

/* 1528 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 1530 */	NdrFcLong( 0x0 ),	/* 0 */
/* 1534 */	NdrFcShort( 0x32 ),	/* 50 */
/* 1536 */	NdrFcShort( 0x14 ),	/* x86 Stack size/offset = 20 */
/* 1538 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1540 */	NdrFcShort( 0x8 ),	/* 8 */
/* 1542 */	0x7,		/* Oi2 Flags:  srv must size, clt must size, has return, */
			0x4,		/* 4 */

	/* Parameter pszCode */

/* 1544 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 1546 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 1548 */	NdrFcShort( 0x30 ),	/* Type Offset=48 */

	/* Parameter pszLogXml */

/* 1550 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 1552 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 1554 */	NdrFcShort( 0x30 ),	/* Type Offset=48 */

	/* Parameter xml */

/* 1556 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 1558 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 1560 */	NdrFcShort( 0x1e ),	/* Type Offset=30 */

	/* Return value */

/* 1562 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 1564 */	NdrFcShort( 0x10 ),	/* x86 Stack size/offset = 16 */
/* 1566 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure iATLWriteHospInfoLocal */

/* 1568 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 1570 */	NdrFcLong( 0x0 ),	/* 0 */
/* 1574 */	NdrFcShort( 0x33 ),	/* 51 */
/* 1576 */	NdrFcShort( 0x14 ),	/* x86 Stack size/offset = 20 */
/* 1578 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1580 */	NdrFcShort( 0x24 ),	/* 36 */
/* 1582 */	0x6,		/* Oi2 Flags:  clt must size, has return, */
			0x4,		/* 4 */

	/* Parameter xml */

/* 1584 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 1586 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 1588 */	NdrFcShort( 0x30 ),	/* Type Offset=48 */

	/* Parameter pszLogXml */

/* 1590 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 1592 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 1594 */	NdrFcShort( 0x30 ),	/* Type Offset=48 */

	/* Parameter pRet */

/* 1596 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 1598 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 1600 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 1602 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 1604 */	NdrFcShort( 0x10 ),	/* x86 Stack size/offset = 16 */
/* 1606 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure iATLRegMsgForNHLog */

/* 1608 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 1610 */	NdrFcLong( 0x0 ),	/* 0 */
/* 1614 */	NdrFcShort( 0x34 ),	/* 52 */
/* 1616 */	NdrFcShort( 0x14 ),	/* x86 Stack size/offset = 20 */
/* 1618 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1620 */	NdrFcShort( 0x8 ),	/* 8 */
/* 1622 */	0x7,		/* Oi2 Flags:  srv must size, clt must size, has return, */
			0x4,		/* 4 */

	/* Parameter bstrServerURL */

/* 1624 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 1626 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 1628 */	NdrFcShort( 0x30 ),	/* Type Offset=48 */

	/* Parameter pszLogXml */

/* 1630 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 1632 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 1634 */	NdrFcShort( 0x30 ),	/* Type Offset=48 */

	/* Parameter bstrReadXML */

/* 1636 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 1638 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 1640 */	NdrFcShort( 0x1e ),	/* Type Offset=30 */

	/* Return value */

/* 1642 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 1644 */	NdrFcShort( 0x10 ),	/* x86 Stack size/offset = 16 */
/* 1646 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure iATLReadCardMessageForNHLog */

/* 1648 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 1650 */	NdrFcLong( 0x0 ),	/* 0 */
/* 1654 */	NdrFcShort( 0x35 ),	/* 53 */
/* 1656 */	NdrFcShort( 0x18 ),	/* x86 Stack size/offset = 24 */
/* 1658 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1660 */	NdrFcShort( 0x8 ),	/* 8 */
/* 1662 */	0x7,		/* Oi2 Flags:  srv must size, clt must size, has return, */
			0x5,		/* 5 */

	/* Parameter pszCardCheckWSDL */

/* 1664 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 1666 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 1668 */	NdrFcShort( 0x30 ),	/* Type Offset=48 */

	/* Parameter pszCardRewritePackageWSDL */

/* 1670 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 1672 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 1674 */	NdrFcShort( 0x30 ),	/* Type Offset=48 */

	/* Parameter pszLogXml */

/* 1676 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 1678 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 1680 */	NdrFcShort( 0x30 ),	/* Type Offset=48 */

	/* Parameter pszXml */

/* 1682 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 1684 */	NdrFcShort( 0x10 ),	/* x86 Stack size/offset = 16 */
/* 1686 */	NdrFcShort( 0x1e ),	/* Type Offset=30 */

	/* Return value */

/* 1688 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 1690 */	NdrFcShort( 0x14 ),	/* x86 Stack size/offset = 20 */
/* 1692 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure iATLReadCardMessageForNHLocal */

/* 1694 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 1696 */	NdrFcLong( 0x0 ),	/* 0 */
/* 1700 */	NdrFcShort( 0x36 ),	/* 54 */
/* 1702 */	NdrFcShort( 0x10 ),	/* x86 Stack size/offset = 16 */
/* 1704 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1706 */	NdrFcShort( 0x8 ),	/* 8 */
/* 1708 */	0x7,		/* Oi2 Flags:  srv must size, clt must size, has return, */
			0x3,		/* 3 */

	/* Parameter pszLogXml */

/* 1710 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 1712 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 1714 */	NdrFcShort( 0x30 ),	/* Type Offset=48 */

	/* Parameter pszXml */

/* 1716 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 1718 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 1720 */	NdrFcShort( 0x1e ),	/* Type Offset=30 */

	/* Return value */

/* 1722 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 1724 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 1726 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure iATLCheckMsgForNHLocal */

/* 1728 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 1730 */	NdrFcLong( 0x0 ),	/* 0 */
/* 1734 */	NdrFcShort( 0x37 ),	/* 55 */
/* 1736 */	NdrFcShort( 0x10 ),	/* x86 Stack size/offset = 16 */
/* 1738 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1740 */	NdrFcShort( 0x8 ),	/* 8 */
/* 1742 */	0x7,		/* Oi2 Flags:  srv must size, clt must size, has return, */
			0x3,		/* 3 */

	/* Parameter pszLogXml */

/* 1744 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 1746 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 1748 */	NdrFcShort( 0x30 ),	/* Type Offset=48 */

	/* Parameter pszXml */

/* 1750 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 1752 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 1754 */	NdrFcShort( 0x1e ),	/* Type Offset=30 */

	/* Return value */

/* 1756 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 1758 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 1760 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure iATLReadOnlyCardMessageForNH */

/* 1762 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 1764 */	NdrFcLong( 0x0 ),	/* 0 */
/* 1768 */	NdrFcShort( 0x38 ),	/* 56 */
/* 1770 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 1772 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1774 */	NdrFcShort( 0x8 ),	/* 8 */
/* 1776 */	0x5,		/* Oi2 Flags:  srv must size, has return, */
			0x2,		/* 2 */

	/* Parameter pszXml */

/* 1778 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 1780 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 1782 */	NdrFcShort( 0x1e ),	/* Type Offset=30 */

	/* Return value */

/* 1784 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 1786 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 1788 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure iATLReadAll */

/* 1790 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 1792 */	NdrFcLong( 0x0 ),	/* 0 */
/* 1796 */	NdrFcShort( 0x39 ),	/* 57 */
/* 1798 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 1800 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1802 */	NdrFcShort( 0x8 ),	/* 8 */
/* 1804 */	0x5,		/* Oi2 Flags:  srv must size, has return, */
			0x2,		/* 2 */

	/* Parameter xml */

/* 1806 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 1808 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 1810 */	NdrFcShort( 0x1e ),	/* Type Offset=30 */

	/* Return value */

/* 1812 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 1814 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 1816 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure iATLRWRecycle */

/* 1818 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 1820 */	NdrFcLong( 0x0 ),	/* 0 */
/* 1824 */	NdrFcShort( 0x3a ),	/* 58 */
/* 1826 */	NdrFcShort( 0x1c ),	/* x86 Stack size/offset = 28 */
/* 1828 */	NdrFcShort( 0x8 ),	/* 8 */
/* 1830 */	NdrFcShort( 0x8 ),	/* 8 */
/* 1832 */	0x7,		/* Oi2 Flags:  srv must size, clt must size, has return, */
			0x6,		/* 6 */

	/* Parameter pszCardCorp */

/* 1834 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 1836 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 1838 */	NdrFcShort( 0x30 ),	/* Type Offset=48 */

	/* Parameter pszXinCorp */

/* 1840 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 1842 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 1844 */	NdrFcShort( 0x30 ),	/* Type Offset=48 */

	/* Parameter counts */

/* 1846 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 1848 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 1850 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Parameter write_xml */

/* 1852 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 1854 */	NdrFcShort( 0x10 ),	/* x86 Stack size/offset = 16 */
/* 1856 */	NdrFcShort( 0x30 ),	/* Type Offset=48 */

	/* Parameter pszXml */

/* 1858 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 1860 */	NdrFcShort( 0x14 ),	/* x86 Stack size/offset = 20 */
/* 1862 */	NdrFcShort( 0x1e ),	/* Type Offset=30 */

	/* Return value */

/* 1864 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 1866 */	NdrFcShort( 0x18 ),	/* x86 Stack size/offset = 24 */
/* 1868 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure iATLReadCardMessageForBothNHLocal */

/* 1870 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 1872 */	NdrFcLong( 0x0 ),	/* 0 */
/* 1876 */	NdrFcShort( 0x3b ),	/* 59 */
/* 1878 */	NdrFcShort( 0x18 ),	/* x86 Stack size/offset = 24 */
/* 1880 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1882 */	NdrFcShort( 0x8 ),	/* 8 */
/* 1884 */	0x6,		/* Oi2 Flags:  clt must size, has return, */
			0x5,		/* 5 */

	/* Parameter pszCardCheckWSDL */

/* 1886 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 1888 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 1890 */	NdrFcShort( 0x30 ),	/* Type Offset=48 */

	/* Parameter pszCardServerURL */

/* 1892 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 1894 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 1896 */	NdrFcShort( 0x30 ),	/* Type Offset=48 */

	/* Parameter pszLogXml */

/* 1898 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 1900 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 1902 */	NdrFcShort( 0x30 ),	/* Type Offset=48 */

	/* Parameter pszXml */

/* 1904 */	NdrFcShort( 0x10b ),	/* Flags:  must size, must free, in, simple ref, */
/* 1906 */	NdrFcShort( 0x10 ),	/* x86 Stack size/offset = 16 */
/* 1908 */	NdrFcShort( 0x30 ),	/* Type Offset=48 */

	/* Return value */

/* 1910 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 1912 */	NdrFcShort( 0x14 ),	/* x86 Stack size/offset = 20 */
/* 1914 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure iATLReadOnlybloodbank */

/* 1916 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 1918 */	NdrFcLong( 0x0 ),	/* 0 */
/* 1922 */	NdrFcShort( 0x3c ),	/* 60 */
/* 1924 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 1926 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1928 */	NdrFcShort( 0x8 ),	/* 8 */
/* 1930 */	0x5,		/* Oi2 Flags:  srv must size, has return, */
			0x2,		/* 2 */

	/* Parameter xml */

/* 1932 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 1934 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 1936 */	NdrFcShort( 0x1e ),	/* Type Offset=30 */

	/* Return value */

/* 1938 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 1940 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 1942 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure iATLReadCardSEQ */

/* 1944 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 1946 */	NdrFcLong( 0x0 ),	/* 0 */
/* 1950 */	NdrFcShort( 0x3d ),	/* 61 */
/* 1952 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 1954 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1956 */	NdrFcShort( 0x8 ),	/* 8 */
/* 1958 */	0x5,		/* Oi2 Flags:  srv must size, has return, */
			0x2,		/* 2 */

	/* Parameter xml */

/* 1960 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 1962 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 1964 */	NdrFcShort( 0x1e ),	/* Type Offset=30 */

	/* Return value */

/* 1966 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 1968 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 1970 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure iATLWritebloodbank */

/* 1972 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 1974 */	NdrFcLong( 0x0 ),	/* 0 */
/* 1978 */	NdrFcShort( 0x3e ),	/* 62 */
/* 1980 */	NdrFcShort( 0x10 ),	/* x86 Stack size/offset = 16 */
/* 1982 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1984 */	NdrFcShort( 0x24 ),	/* 36 */
/* 1986 */	0x6,		/* Oi2 Flags:  clt must size, has return, */
			0x3,		/* 3 */

	/* Parameter xml */

/* 1988 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 1990 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 1992 */	NdrFcShort( 0x30 ),	/* Type Offset=48 */

	/* Parameter pRet */

/* 1994 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 1996 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 1998 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */

/* 2000 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 2002 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 2004 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure iATLReadOnlyHospLocal */

/* 2006 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 2008 */	NdrFcLong( 0x0 ),	/* 0 */
/* 2012 */	NdrFcShort( 0x3f ),	/* 63 */
/* 2014 */	NdrFcShort( 0x10 ),	/* x86 Stack size/offset = 16 */
/* 2016 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2018 */	NdrFcShort( 0x8 ),	/* 8 */
/* 2020 */	0x7,		/* Oi2 Flags:  srv must size, clt must size, has return, */
			0x3,		/* 3 */

	/* Parameter pszLogXml */

/* 2022 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 2024 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 2026 */	NdrFcShort( 0x30 ),	/* Type Offset=48 */

	/* Parameter xml */

/* 2028 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 2030 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 2032 */	NdrFcShort( 0x1e ),	/* Type Offset=30 */

	/* Return value */

/* 2034 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 2036 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 2038 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure iATLScanCardXML */

/* 2040 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 2042 */	NdrFcLong( 0x0 ),	/* 0 */
/* 2046 */	NdrFcShort( 0x40 ),	/* 64 */
/* 2048 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 2050 */	NdrFcShort( 0x0 ),	/* 0 */
/* 2052 */	NdrFcShort( 0x8 ),	/* 8 */
/* 2054 */	0x5,		/* Oi2 Flags:  srv must size, has return, */
			0x2,		/* 2 */

	/* Parameter xml */

/* 2056 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 2058 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 2060 */	NdrFcShort( 0x1e ),	/* Type Offset=30 */

	/* Return value */

/* 2062 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 2064 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 2066 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

			0x0
        }
    };

static const MIDL_TYPE_FORMAT_STRING __MIDL_TypeFormatString =
    {
        0,
        {
			NdrFcShort( 0x0 ),	/* 0 */
/*  2 */	
			0x11, 0x4,	/* FC_RP [alloced_on_stack] */
/*  4 */	NdrFcShort( 0x1a ),	/* Offset= 26 (30) */
/*  6 */	
			0x13, 0x0,	/* FC_OP */
/*  8 */	NdrFcShort( 0xc ),	/* Offset= 12 (20) */
/* 10 */	
			0x1b,		/* FC_CARRAY */
			0x1,		/* 1 */
/* 12 */	NdrFcShort( 0x2 ),	/* 2 */
/* 14 */	0x9,		/* Corr desc: FC_ULONG */
			0x0,		/*  */
/* 16 */	NdrFcShort( 0xfffc ),	/* -4 */
/* 18 */	0x6,		/* FC_SHORT */
			0x5b,		/* FC_END */
/* 20 */	
			0x17,		/* FC_CSTRUCT */
			0x3,		/* 3 */
/* 22 */	NdrFcShort( 0x8 ),	/* 8 */
/* 24 */	NdrFcShort( 0xfff2 ),	/* Offset= -14 (10) */
/* 26 */	0x8,		/* FC_LONG */
			0x8,		/* FC_LONG */
/* 28 */	0x5c,		/* FC_PAD */
			0x5b,		/* FC_END */
/* 30 */	0xb4,		/* FC_USER_MARSHAL */
			0x83,		/* 131 */
/* 32 */	NdrFcShort( 0x0 ),	/* 0 */
/* 34 */	NdrFcShort( 0x4 ),	/* 4 */
/* 36 */	NdrFcShort( 0x0 ),	/* 0 */
/* 38 */	NdrFcShort( 0xffe0 ),	/* Offset= -32 (6) */
/* 40 */	
			0x11, 0xc,	/* FC_RP [alloced_on_stack] [simple_pointer] */
/* 42 */	0x8,		/* FC_LONG */
			0x5c,		/* FC_PAD */
/* 44 */	
			0x12, 0x0,	/* FC_UP */
/* 46 */	NdrFcShort( 0xffe6 ),	/* Offset= -26 (20) */
/* 48 */	0xb4,		/* FC_USER_MARSHAL */
			0x83,		/* 131 */
/* 50 */	NdrFcShort( 0x0 ),	/* 0 */
/* 52 */	NdrFcShort( 0x4 ),	/* 4 */
/* 54 */	NdrFcShort( 0x0 ),	/* 0 */
/* 56 */	NdrFcShort( 0xfff4 ),	/* Offset= -12 (44) */
/* 58 */	
			0x11, 0x8,	/* FC_RP [simple_pointer] */
/* 60 */	0x8,		/* FC_LONG */
			0x5c,		/* FC_PAD */
/* 62 */	
			0x11, 0x0,	/* FC_RP */
/* 64 */	NdrFcShort( 0xfff0 ),	/* Offset= -16 (48) */

			0x0
        }
    };

static const USER_MARSHAL_ROUTINE_QUADRUPLE UserMarshalRoutines[ WIRE_MARSHAL_TABLE_SIZE ] = 
        {
            
            {
            BSTR_UserSize
            ,BSTR_UserMarshal
            ,BSTR_UserUnmarshal
            ,BSTR_UserFree
            }

        };



/* Object interface: IUnknown, ver. 0.0,
   GUID={0x00000000,0x0000,0x0000,{0xC0,0x00,0x00,0x00,0x00,0x00,0x00,0x46}} */


/* Object interface: IDispatch, ver. 0.0,
   GUID={0x00020400,0x0000,0x0000,{0xC0,0x00,0x00,0x00,0x00,0x00,0x00,0x46}} */


/* Object interface: ICardProcess, ver. 0.0,
   GUID={0x02D30C94,0xA1B9,0x4663,{0x99,0xA9,0xC9,0xF8,0x56,0xED,0x31,0x37}} */

#pragma code_seg(".orpc")
static const unsigned short ICardProcess_FormatStringOffsetTable[] =
    {
    (unsigned short) -1,
    (unsigned short) -1,
    (unsigned short) -1,
    (unsigned short) -1,
    0,
    28,
    56,
    90,
    124,
    158,
    186,
    214,
    248,
    294,
    346,
    380,
    408,
    436,
    476,
    516,
    556,
    584,
    624,
    658,
    692,
    726,
    754,
    782,
    810,
    838,
    872,
    900,
    934,
    968,
    1002,
    1036,
    1070,
    1116,
    1162,
    1202,
    1242,
    1282,
    1322,
    1356,
    1402,
    1448,
    1488,
    1528,
    1568,
    1608,
    1648,
    1694,
    1728,
    1762,
    1790,
    1818,
    1870,
    1916,
    1944,
    1972,
    2006,
    2040
    };

static const MIDL_STUBLESS_PROXY_INFO ICardProcess_ProxyInfo =
    {
    &Object_StubDesc,
    __MIDL_ProcFormatString.Format,
    &ICardProcess_FormatStringOffsetTable[-3],
    0,
    0,
    0
    };


static const MIDL_SERVER_INFO ICardProcess_ServerInfo = 
    {
    &Object_StubDesc,
    0,
    __MIDL_ProcFormatString.Format,
    &ICardProcess_FormatStringOffsetTable[-3],
    0,
    0,
    0,
    0};
CINTERFACE_PROXY_VTABLE(65) _ICardProcessProxyVtbl = 
{
    &ICardProcess_ProxyInfo,
    &IID_ICardProcess,
    IUnknown_QueryInterface_Proxy,
    IUnknown_AddRef_Proxy,
    IUnknown_Release_Proxy ,
    0 /* (void *) (INT_PTR) -1 /* IDispatch::GetTypeInfoCount */ ,
    0 /* (void *) (INT_PTR) -1 /* IDispatch::GetTypeInfo */ ,
    0 /* (void *) (INT_PTR) -1 /* IDispatch::GetIDsOfNames */ ,
    0 /* IDispatch_Invoke_Proxy */ ,
    (void *) (INT_PTR) -1 /* ICardProcess::iATLGetCardVersion */ ,
    (void *) (INT_PTR) -1 /* ICardProcess::iATLCardInit */ ,
    (void *) (INT_PTR) -1 /* ICardProcess::iATLReadInfo */ ,
    (void *) (INT_PTR) -1 /* ICardProcess::iATLWriteInfo */ ,
    (void *) (INT_PTR) -1 /* ICardProcess::iATLQueryInfo */ ,
    (void *) (INT_PTR) -1 /* ICardProcess::iATLerr */ ,
    (void *) (INT_PTR) -1 /* ICardProcess::iATLFormatCard */ ,
    (void *) (INT_PTR) -1 /* ICardProcess::iATLCreateCard */ ,
    (void *) (INT_PTR) -1 /* ICardProcess::iATLPrintCard */ ,
    (void *) (INT_PTR) -1 /* ICardProcess::iATLPatchCard */ ,
    (void *) (INT_PTR) -1 /* ICardProcess::iATLCreateCardData */ ,
    (void *) (INT_PTR) -1 /* ICardProcess::iATLScanCard */ ,
    (void *) (INT_PTR) -1 /* ICardProcess::iATLCardClose */ ,
    (void *) (INT_PTR) -1 /* ICardProcess::iATLReadCardMessageForNH */ ,
    (void *) (INT_PTR) -1 /* ICardProcess::iATLReadHISInfo */ ,
    (void *) (INT_PTR) -1 /* ICardProcess::iATLReadInfoForXJ */ ,
    (void *) (INT_PTR) -1 /* ICardProcess::iATLCardIsEmpty */ ,
    (void *) (INT_PTR) -1 /* ICardProcess::iATLCheckMsgForNH */ ,
    (void *) (INT_PTR) -1 /* ICardProcess::iATLReadConfigMsg */ ,
    (void *) (INT_PTR) -1 /* ICardProcess::iATLRegMsgForNH */ ,
    (void *) (INT_PTR) -1 /* ICardProcess::iATLEncryFile */ ,
    (void *) (INT_PTR) -1 /* ICardProcess::iATLGetPrinterList */ ,
    (void *) (INT_PTR) -1 /* ICardProcess::iATLReadOnlyHIS */ ,
    (void *) (INT_PTR) -1 /* ICardProcess::iATLCardOpen */ ,
    (void *) (INT_PTR) -1 /* ICardProcess::iATLCardDeinit */ ,
    (void *) (INT_PTR) -1 /* ICardProcess::iATLCreateLicense */ ,
    (void *) (INT_PTR) -1 /* ICardProcess::iATLFormatHospInfo */ ,
    (void *) (INT_PTR) -1 /* ICardProcess::iATLWriteHospInfo */ ,
    (void *) (INT_PTR) -1 /* ICardProcess::iATLReadClinicInfo */ ,
    (void *) (INT_PTR) -1 /* ICardProcess::iATLReadMedicalInfo */ ,
    (void *) (INT_PTR) -1 /* ICardProcess::iATLReadFeeInfo */ ,
    (void *) (INT_PTR) -1 /* ICardProcess::iATLReadOnlyHISLog */ ,
    (void *) (INT_PTR) -1 /* ICardProcess::iATLReadInfoForXJLog */ ,
    (void *) (INT_PTR) -1 /* ICardProcess::iATLReadHISInfoLog */ ,
    (void *) (INT_PTR) -1 /* ICardProcess::iATLReadMedicalInfoLog */ ,
    (void *) (INT_PTR) -1 /* ICardProcess::iATLReadFeeInfoLog */ ,
    (void *) (INT_PTR) -1 /* ICardProcess::iATLWriteHospInfoLog */ ,
    (void *) (INT_PTR) -1 /* ICardProcess::iATLReadClinicInfoLog */ ,
    (void *) (INT_PTR) -1 /* ICardProcess::iATLReadOnlyHISLocal */ ,
    (void *) (INT_PTR) -1 /* ICardProcess::iATLReadInfoForXJLocal */ ,
    (void *) (INT_PTR) -1 /* ICardProcess::iATLReadHISInfoLocal */ ,
    (void *) (INT_PTR) -1 /* ICardProcess::iATLReadMedicalInfoLocal */ ,
    (void *) (INT_PTR) -1 /* ICardProcess::iATLReadFeeInfoLocal */ ,
    (void *) (INT_PTR) -1 /* ICardProcess::iATLReadClinicInfoLocal */ ,
    (void *) (INT_PTR) -1 /* ICardProcess::iATLWriteHospInfoLocal */ ,
    (void *) (INT_PTR) -1 /* ICardProcess::iATLRegMsgForNHLog */ ,
    (void *) (INT_PTR) -1 /* ICardProcess::iATLReadCardMessageForNHLog */ ,
    (void *) (INT_PTR) -1 /* ICardProcess::iATLReadCardMessageForNHLocal */ ,
    (void *) (INT_PTR) -1 /* ICardProcess::iATLCheckMsgForNHLocal */ ,
    (void *) (INT_PTR) -1 /* ICardProcess::iATLReadOnlyCardMessageForNH */ ,
    (void *) (INT_PTR) -1 /* ICardProcess::iATLReadAll */ ,
    (void *) (INT_PTR) -1 /* ICardProcess::iATLRWRecycle */ ,
    (void *) (INT_PTR) -1 /* ICardProcess::iATLReadCardMessageForBothNHLocal */ ,
    (void *) (INT_PTR) -1 /* ICardProcess::iATLReadOnlybloodbank */ ,
    (void *) (INT_PTR) -1 /* ICardProcess::iATLReadCardSEQ */ ,
    (void *) (INT_PTR) -1 /* ICardProcess::iATLWritebloodbank */ ,
    (void *) (INT_PTR) -1 /* ICardProcess::iATLReadOnlyHospLocal */ ,
    (void *) (INT_PTR) -1 /* ICardProcess::iATLScanCardXML */
};


static const PRPC_STUB_FUNCTION ICardProcess_table[] =
{
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2
};

CInterfaceStubVtbl _ICardProcessStubVtbl =
{
    &IID_ICardProcess,
    &ICardProcess_ServerInfo,
    65,
    &ICardProcess_table[-3],
    CStdStubBuffer_DELEGATING_METHODS
};

static const MIDL_STUB_DESC Object_StubDesc = 
    {
    0,
    NdrOleAllocate,
    NdrOleFree,
    0,
    0,
    0,
    0,
    0,
    __MIDL_TypeFormatString.Format,
    1, /* -error bounds_check flag */
    0x20000, /* Ndr library version */
    0,
    0x600016e, /* MIDL Version 6.0.366 */
    0,
    UserMarshalRoutines,
    0,  /* notify & notify_flag routine table */
    0x1, /* MIDL flag */
    0, /* cs routines */
    0,   /* proxy/server info */
    0   /* Reserved5 */
    };

const CInterfaceProxyVtbl * _BHGX_CardActiveX_ProxyVtblList[] = 
{
    ( CInterfaceProxyVtbl *) &_ICardProcessProxyVtbl,
    0
};

const CInterfaceStubVtbl * _BHGX_CardActiveX_StubVtblList[] = 
{
    ( CInterfaceStubVtbl *) &_ICardProcessStubVtbl,
    0
};

PCInterfaceName const _BHGX_CardActiveX_InterfaceNamesList[] = 
{
    "ICardProcess",
    0
};

const IID *  _BHGX_CardActiveX_BaseIIDList[] = 
{
    &IID_IDispatch,
    0
};


#define _BHGX_CardActiveX_CHECK_IID(n)	IID_GENERIC_CHECK_IID( _BHGX_CardActiveX, pIID, n)

int __stdcall _BHGX_CardActiveX_IID_Lookup( const IID * pIID, int * pIndex )
{
    
    if(!_BHGX_CardActiveX_CHECK_IID(0))
        {
        *pIndex = 0;
        return 1;
        }

    return 0;
}

const ExtendedProxyFileInfo BHGX_CardActiveX_ProxyFileInfo = 
{
    (PCInterfaceProxyVtblList *) & _BHGX_CardActiveX_ProxyVtblList,
    (PCInterfaceStubVtblList *) & _BHGX_CardActiveX_StubVtblList,
    (const PCInterfaceName * ) & _BHGX_CardActiveX_InterfaceNamesList,
    (const IID ** ) & _BHGX_CardActiveX_BaseIIDList,
    & _BHGX_CardActiveX_IID_Lookup, 
    1,
    2,
    0, /* table of [async_uuid] interfaces */
    0, /* Filler1 */
    0, /* Filler2 */
    0  /* Filler3 */
};
#pragma optimize("", on )
#if _MSC_VER >= 1200
#pragma warning(pop)
#endif


#endif /* !defined(_M_IA64) && !defined(_M_AMD64)*/


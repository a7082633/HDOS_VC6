// EducationDemoDlg.cpp : implementation file
//

#include "stdafx.h"
#include "EducationDemo.h"
#include "EducationDemoDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CEducationDemoDlg dialog

CEducationDemoDlg::CEducationDemoDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CEducationDemoDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CEducationDemoDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CEducationDemoDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CEducationDemoDlg)
	DDX_Control(pDX, IDC_Read, m_cread);
	DDX_Control(pDX, IDC_RICHEDIT1, m_rich);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CEducationDemoDlg, CDialog)
	//{{AFX_MSG_MAP(CEducationDemoDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_IDauthentication, OnIDauthentication)
	ON_BN_CLICKED(IDC_IssueDocuments, OnIssueDocuments)
	ON_BN_CLICKED(IDC_IssueDocumentsW, OnIssueDocumentsW)
	ON_BN_CLICKED(IDC_CardAuthentication, OnCardAuthentication)
	ON_BN_CLICKED(IDC_SchoolSet, OnSchoolSet)
	ON_BN_CLICKED(IDC_EatSet, OnEatSet)
	ON_BN_CLICKED(IDC_UseSet, OnUseSet)
	ON_BN_CLICKED(IDC_AppLock, OnAppLock)
	ON_BN_CLICKED(IDC_AppUnlock, OnAppUnlock)
	ON_BN_CLICKED(IDC_ChangePIN, OnChangePIN)
	ON_BN_CLICKED(IDC_UnlockPin, OnUnlockPin)
	ON_BN_CLICKED(IDC_Clear, OnClear)
	ON_BN_CLICKED(IDC_ReadADF, OnReadADF)
	ON_BN_CLICKED(IDC_WriteADF, OnWriteADF)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CEducationDemoDlg message handlers

BOOL CEducationDemoDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	

	SetDlgItemText(IDC_PIN,"111111");
	SetDlgItemText(IDC_CardCode,"0102030405");
	SetDlgItemText(IDC_AppLogo,"0102030405");
	SetDlgItemText(IDC_AppEdition,"01");
	SetDlgItemText(IDC_CardLogo,"00");
	SetDlgItemText(IDC_CardNum,"20150316161435000037");
	SetDlgItemText(IDC_OpenDate,"20150423");
	SetDlgItemText(IDC_EffectiveDate,"20150423");
	SetDlgItemText(IDC_FCI,"0102");
	SetDlgItemText(IDC_StateCode,"01");
	SetDlgItemText(IDC_Semester,"0002");
	SetDlgItemText(IDC_EffectiveDate5,"20150423");
	SetDlgItemText(IDC_SetDate,"20150423");
	SetDlgItemText(IDC_QLogo,"02");
	SetDlgItemText(IDC_AllTimes,"0001");
	SetDlgItemText(IDC_OpenDate6,"20150423");
	SetDlgItemText(IDC_EndDate6,"20150423");
	SetDlgItemText(IDC_EatType,"00000002");
	SetDlgItemText(IDC_SerialNum,"0001");
	SetDlgItemText(IDC_LastUseTime,"20150423180630");
	SetDlgItemText(IDC_Read,"ADF0");

	m_cread.AddString("ADF0");
	m_cread.AddString("ADF1");
	m_cread.AddString("ADF2");
	m_cread.AddString("ADF3");
	m_cread.AddString("ADF4");
	m_cread.AddString("ADF6");
	m_cread.AddString("ADF9");


	// TODO: Add extra initialization here
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CEducationDemoDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CEducationDemoDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CEducationDemoDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

#include "SSSE32.H"
#pragma comment(lib,"SSSE32")

long g_hReader=0;

int chartoint(char c)
{
	switch (c)
	{
	case '0':
		return 0;break;
	case '1':
		return 1;break;
	case '2':
		return 2;break;
	case '3':
		return 3;break;
	case '4':
		return 4;break;
	case '5':
		return 5;break;
	case '6':
		return 6;break;
	case '7':
		return 7;break;
	case '8':
		return 8;break;
	case '9':
		return 9;break;
	case 'A':
	case 'a':
		return 10;break;
	case 'B':
	case 'b':
		return 11;break;
	case 'C':
	case 'c':
		return 12;break;
	case 'D':
	case 'd':
		return 13;break;
	case 'E':
	case 'e':
		return 14;break;
	case 'F':
	case 'f':
		return 15;break;
	default:return 1000;
		break;
	}
	
	return 0;
}

int CEducationDemoDlg::Excute(char *cmd, char *Response)
{
	int re=0;
	int len = strlen(cmd);
	unsigned char hcmd[100]={0};
	unsigned char hResponse[300]={0};
    for(int i=0;i<(len/2);i++)
    {
		hcmd[i]= chartoint(cmd[2*i])*16+chartoint(cmd[2*i+1]);
	}
	
	re = PICC_Reader_Application(g_hReader,len/2,hcmd,hResponse);
	if(re<=0)
	{
		return 200;
	}
	
	
	if(hResponse[re-2]==0x61)
	{
		memcpy(hcmd,"\x00\xc0\x00\x00\x00",5);
		hcmd[4]=hResponse[re-1];
		re = PICC_Reader_Application(g_hReader,5,hcmd,hResponse);
		if(re<=0)
		{
			return 200;
		}
		if(hResponse[re-2]!=0x90 && hResponse[re-2]!=0x61)
			return 0-hResponse[re-2]*0x100-hResponse[re-1];
	}
	if(hResponse[re-2]==0x6C)
	{
		hcmd[4]=hResponse[re-1];
		re = PICC_Reader_Application(g_hReader,5,hcmd,hResponse);
		if(re<=0)
		{
			return 200;
		}
		if(hResponse[re-2]!=0x90 && hResponse[re-2]!=0x61)
			return hResponse[re-2]*0x100-hResponse[re-1];
		
		if(hResponse[re-2]==0x61)
		{
			memcpy(hcmd,"\x00\xc0\x00\x00\x00",5);
			hcmd[4]=hResponse[re-1];
			re = PICC_Reader_Application(g_hReader,5,hcmd,hResponse);
			if(re<=0)
			{
				return 200;
			}
			if(hResponse[re-2]!=0x90 && hResponse[re-2]!=0x61)
				return hResponse[re-2]*0x100-hResponse[re-1];
		}
	}
	else if(hResponse[re-2]!=0x90 && hResponse[re-2]!=0x61)
		return hResponse[re-2]*0x100+hResponse[re-1];
	
	
	CString sNO;
	CString sAccp;
	for(i=0;i<re;i++)
	{
		sAccp.Format("%02X",hResponse[i]);
		sNO+=sAccp;	
	}
	strcpy(Response,(LPCSTR)sNO);
	return 0;

}

int CEducationDemoDlg::ExcutePSAM(char *cmd, char *Response)
{
	int re=0;
	int len = strlen(cmd);
	unsigned char hcmd[1000]={0};
	unsigned char hResponse[1000]={0};
    for(int i=0;i<(len/2);i++)
    {
		hcmd[i]= chartoint(cmd[2*i])*16+chartoint(cmd[2*i+1]);
	}
	
	re = ICC_Reader_Application(g_hReader,0x01,len/2,hcmd,hResponse);
	if(re<=0)
	{
		return 200;
	}
	
	
	if(hResponse[re-2]==0x61)
	{
		memcpy(hcmd,"\x00\xc0\x00\x00\x00",5);
		hcmd[4]=hResponse[re-1];
		re = ICC_Reader_Application(g_hReader,0x01,5,hcmd,hResponse);
		if(re<=0)
		{
			return 200;
		}
		if(hResponse[re-2]!=0x90 && hResponse[re-2]!=0x61)
			return 0-hResponse[re-2]*0x100-hResponse[re-1];
	}
	if(hResponse[re-2]==0x6C)
	{
		hcmd[4]=hResponse[re-1];
		re = ICC_Reader_Application(g_hReader,0x01,5,hcmd,hResponse);
		if(re<=0)
		{
			return 200;
		}
		if(hResponse[re-2]!=0x90 && hResponse[re-2]!=0x61)
			return 0-hResponse[re-2]*0x100-hResponse[re-1];
		
		if(hResponse[re-2]==0x61)
		{
			memcpy(hcmd,"\x00\xc0\x00\x00\x00",5);
			hcmd[4]=hResponse[re-1];
			re = ICC_Reader_Application(g_hReader,0x01,5,hcmd,hResponse);
			if(re<=0)
			{
				return 200;
			}
			if(hResponse[re-2]!=0x90 && hResponse[re-2]!=0x61)
				return hResponse[re-2]*0x100-hResponse[re-1];
		}
	}
	else if(hResponse[re-2]!=0x90 && hResponse[re-2]!=0x61)
		return hResponse[re-2]*0x100-hResponse[re-1];
	
	
	CString sNO;
	CString sAccp;
	for(i=0;i<re;i++)
	{
		sAccp.Format("%02X",hResponse[i]);
		sNO+=sAccp;	
	}
	strcpy(Response,(LPCSTR)sNO);
	return 0;
}

int CEducationDemoDlg::ExcuteASC(char *cmd, char *OutData)
{
	int re=0;
	int len = strlen(cmd);
	unsigned char hcmd[100]={0};
	unsigned char hResponse[300]={0};
    for(int i=0;i<(len/2);i++)
    {
		hcmd[i]= chartoint(cmd[2*i])*16+chartoint(cmd[2*i+1]);
	}
	
	re = PICC_Reader_Application(g_hReader,len/2,hcmd,hResponse);
	if(re<=0)
	{
		return 200;
	}
	
	
	if(hResponse[re-2]==0x61)
	{
		memcpy(hcmd,"\x00\xc0\x00\x00\x00",5);
		hcmd[4]=hResponse[re-1];
		re = PICC_Reader_Application(g_hReader,5,hcmd,hResponse);
		if(re<=0)
		{
			return 200;
		}
		if(hResponse[re-2]!=0x90 && hResponse[re-2]!=0x61)
			return 0-hResponse[re-2]*0x100-hResponse[re-1];
	}
	if(hResponse[re-2]==0x6C)
	{
		hcmd[4]=hResponse[re-1];
		re = PICC_Reader_Application(g_hReader,5,hcmd,hResponse);
		if(re<=0)
		{
			return 200;
		}
		if(hResponse[re-2]!=0x90 && hResponse[re-2]!=0x61)
			return hResponse[re-2]*0x100-hResponse[re-1];
		
		if(hResponse[re-2]==0x61)
		{
			memcpy(hcmd,"\x00\xc0\x00\x00\x00",5);
			hcmd[4]=hResponse[re-1];
			re = PICC_Reader_Application(g_hReader,5,hcmd,hResponse);
			if(re<=0)
			{
				return 200;
			}
			if(hResponse[re-2]!=0x90 && hResponse[re-2]!=0x61)
				return 0-hResponse[re-2]*0x100-hResponse[re-1];
		}
	}
	else if(hResponse[re-2]!=0x90 && hResponse[re-2]!=0x61)
		return hResponse[re-2]*0x100-hResponse[re-1];

    memcpy(OutData,hResponse,re-2);
	
	return 0;

}

int CEducationDemoDlg::OpenUSB()
{
	int re =0;
	unsigned char uid[5];
	unsigned char Response[51];
	
	g_hReader = ICC_Reader_Open("USB1");
	if(g_hReader<=0)
		return 101;
	
	re = PICC_Reader_SetTypeA(g_hReader);
	if(re!=0)
	{
		return 102;
	}
	re=PICC_Reader_Request(g_hReader);
	if(re!=0)
	{
		return 103;
	}
	re = PICC_Reader_anticoll(g_hReader,uid);
	if(re!=0)
	{
		return 104;
	}
	re = PICC_Reader_Select(g_hReader,0x41);
	if(re!=0)
	{
		return 105;
	}
	re = PICC_Reader_PowerOnTypeA(g_hReader,Response);
	if(re<0)
	{
		return 106;
	}
	
	CString sNO;
	CString sAccp;
	for(int i=0;i<re;i++)
	{
		sAccp.Format("%02X",Response[i]);
		sNO+=sAccp;	
	}

	return 0;
}

int CEducationDemoDlg::newhuo(char *leftdata,char *rightdata,char *newdata)
{
	int re=0;
	int len1=strlen(leftdata);
	int len2=strlen(rightdata);
	unsigned char left1[100]={0};
	unsigned char right1[100]={0};
	unsigned char new1[100]={0};

	if(len1!=len2)
		return -1;

	for (int i=0;i<len1/2;i++)
	{
		left1[i]= chartoint(leftdata[2*i])*16+chartoint(leftdata[2*i+1]);
	}
	for (i=0;i<len2/2;i++)
	{
		right1[i]= chartoint(rightdata[2*i])*16+chartoint(rightdata[2*i+1]);
	}
	for (i=0;i<len2/2;i++)
	{
		new1[i]=left1[i]^right1[i];
	}

	CString sNO;
	CString sAccp;
	for(i=0;i<len1/2;i++)
	{
		sAccp.Format("%02X",new1[i]);
		sNO+=sAccp;	
	}
	strcpy(newdata,(LPCSTR)sNO);

	return 0;
}

void CEducationDemoDlg::OnIDauthentication() 
{
		CString spin("");
	char cpin[100]={0};
	char ch[50]={0};
	GetDlgItemText(IDC_PIN,spin);
	if(spin.GetLength()!=6)
	{
		MessageBox("PIN���ȴ���");
		return ;
	}
	memcpy(ch,spin,6);
	for (int i=0;i<6;i++)
	{
		sprintf(cpin+2*i,"%02X",ch[i]);
	}

	int re=0;
	char resp[1000]={0};
	unsigned char Resp[100]={0};
	char Random[50]={0};
	char Random2[50]={0};
	char RandomSAM[50]={0};
	char fsdata1[100]={0};
	char fsdata2[100]={0};
	char cmd[1000]={0};
	char endata[100]={0};
	char endata_left[50]={0};
	char endata_right[50]={0};
	char endata_new[50]={0};
	char MAC[50]={0};
	char IDNum[100]={0};
	char CardNum[100]={0};
	char UserData0[500]={0};
	char UserData1[500]={0};
	char UserData2[500]={0};
	char UserData3[500]={0};
	char UserData4[500]={0};
	char UserData5[500]={0};
	char EsamData0[500]={0};
	char EsamData1[500]={0};
	char EsamData2[500]={0};
	char EsamData3[500]={0};
	char EsamData4[500]={0};

	CString str("");

	re=OpenUSB();
	if (re!=0)
	{
		MessageBox("������δ���ӵ��Ի�Ƭ�ϵ�ʧ��");
		return;
	}


	re=Excute("00A4000000",resp);
	if (re!=0)
	{
		MessageBox("00A4000000--err");
		return;
	}
	
	re=Excute("00A4000002ADF3",resp);
	if (re!=0)
	{
		MessageBox("00A4000002ADF3--err");
		return;
	}

	memcpy(cmd,"0020000006",10);
	memcpy(cmd+10,cpin,12);
	re=Excute(cmd,resp);
	if (re!=0)
	{
		spin.Format("%d 00200000--err",re);
		MessageBox(spin);
		return;
	}

	re=Excute("00A4000000",resp);
	if (re!=0)
	{
		MessageBox("00A4000000--err");
		return;
	}
	
	re=Excute("00A4000002ADF0",resp);
	if (re!=0)
	{
		MessageBox("00A4000002ADF0--err");
		return;
	}

	re=Excute("00A4000002EF02",resp);
	if (re!=0)
	{
		MessageBox("00A4000002EF02--err");
		return;
	}
	
	re=Excute("0084000008",resp);
	if (re!=0)
	{
		MessageBox("0084000008--err");
		return;
	}

	memcpy(fsdata1,"1122334455667788",16);
	memcpy(fsdata2,resp,16);

	re=ICC_Reader_pre_PowerOn(g_hReader,0x01,Resp);
	if (re<=0)
	{
		MessageBox("ESAM--err");
		return;
	}

	re=ExcutePSAM("0084000008",resp);
	if (re!=0)
	{
		MessageBox("SAM-0084000008--err");
		return;
	}
	memcpy(Random,resp,16);
	
	re=ExcutePSAM("00A4000000",resp);
	if (re!=0)
	{
		MessageBox("SAM-00A4000000--err");
		return;
	}
	
	re=ExcutePSAM("00A4000002DF01",resp);
	if (re!=0)
	{
		MessageBox("SAM-00A4000002DF01--err");
		return;
	}


	memcpy(cmd,"801A270108",10);
	memcpy(cmd+10,fsdata1,16);
	re=ExcutePSAM(cmd,resp);
	if (re!=0)
	{
		MessageBox("SAM-801A270108--err");
		return;
	}
	
	memcpy(cmd,"80FA000010",10);
	memcpy(cmd+10,fsdata2,16);
	memcpy(cmd+26,"0000000000000000",16);
	re=ExcutePSAM(cmd,resp);
	if (re!=0)
	{
		MessageBox("SAM-80FA000010--err");
		return;
	}
	
	memcpy(endata,resp,32);
	
	memset(cmd,0,100);
	
	memcpy(cmd,"801A000C10",10);
	memcpy(cmd+10,endata,32);
	re=ExcutePSAM(cmd,resp);
	if (re!=0)
	{
		MessageBox("SAM-801A000C10--err");
		return;
	}
	
	memset(cmd,0,100);
	memcpy(cmd,"80FA000010",10);
	memcpy(cmd+10,Random,16);
	memcpy(cmd+26,"0000000000000000",16);
	re=ExcutePSAM(cmd,resp);
	if (re!=0)
	{
		MessageBox("SAM-80FA000010--err");
		return;
	}
	
	memcpy(endata_left,resp,16);
	memcpy(endata_right,resp+16,16);
	
	re=newhuo(endata_left,endata_right,endata_new);
	if(re!=0)
	{
		MessageBox("SAM-left_right--err");
		return;
	}
	
	memset(cmd,0,100);
	memcpy(cmd,"0082000A11",10);
	memcpy(cmd+10,endata_new,16);
	memcpy(cmd+26,Random,16);
	memcpy(cmd+42,"00",2);
	re=Excute(cmd,resp);
	if (re!=0)
	{
		MessageBox("0082000A11--err");
		return;
	}
	
	re=Excute("00B000910D",resp);
	if (re!=0)
	{
		MessageBox("00B000910D--err");
		return;
	}
	memcpy(IDNum,resp+6,20);  //��ý���������ʶ���

	str+="��ý���������ʶ���:";
	str+=IDNum;
	str+="\r\n";

	re=Excute("00A4000002EF01",resp);
	if (re!=0)
	{
		MessageBox("00A4000002EF01--err");
		return;
	}

	re=Excute("00B000180C",resp);
	if (re!=0)
	{
		MessageBox("00B000180C--err");
		return;
	}
	memcpy(CardNum,resp+4,20);
	str+="���Ӧ�����к�:";
	str+=CardNum;
	str+="\r\n";

	re=Excute("0084000008",resp);
	if (re!=0)
	{
		MessageBox("0084000008--err");
		return;
	}
	memcpy(Random,resp,16);

	re=Excute("00A4000000",resp);
	if (re!=0)
	{
		MessageBox("00A4000000--err");
		return;
	}
	
	re=Excute("00A4000002ADF3",resp);
	if (re!=0)
	{
		MessageBox("00A4000002ADF3--err");
		return;
	}

	memset(cmd,0,200);
	memcpy(cmd,"0088000008",10);
	memcpy(cmd+10,Random,16);
	re=Excute(cmd,resp);
	if (re!=0)
	{
		MessageBox("00A4000002ADF3--err");
		return;
	}

	memcpy(UserData4,resp+2,14);
	memcpy(UserData5,resp+0x28*2,0x40*2); //128

	memset(cmd,0,200);
	memcpy(cmd,"807D00FF19",10);
	memcpy(cmd+10,UserData4,14);
	memcpy(cmd+24,IDNum,20);
	memcpy(cmd+44,Random,16);
	memset(resp,0,1000);
	re=ExcutePSAM(cmd,resp);
	if (re!=0)
	{
		MessageBox("SAM-807D00FF19--err");
		return;
	}

	memcpy(EsamData0,resp,64);//xx 64

	re=ExcutePSAM("00A4000000",resp);
	if (re!=0)
	{
		MessageBox("SAM-00A4000000--err");
		return;
	}
	
	re=ExcutePSAM("00A4000002DF01",resp);
	if (re!=0)
	{
		MessageBox("SAM-00A4000002DF01--err");
		return;
	}

	re=ExcutePSAM("00A40000020004",resp);
	if (re!=0)
	{
		MessageBox("SAM-00A40000020004--err");
		return;
	}

	re=ExcutePSAM("00B00000F0",resp);
	if (re!=0)
	{
		MessageBox("SAM-00B00000F0--err");
		return;
	}

	memcpy(EsamData1,resp+(0x9C*2),0x40*2);//128

	memset(resp,0,1000);
	re=ExcutePSAM("00B000F0A3",resp);
	if (re!=0)
	{
		MessageBox("SAM-00B000F0A3--err");
		return;
	}

	memcpy(EsamData2,resp,326);  //xx 326

	re=Excute("00A4000002ADF3",resp);
	if (re!=0)
	{
		MessageBox("00A4000002ADF3--err");
		return;
	}


	re=Excute("00A4000002EF04",resp);
	if (re!=0)
	{
		MessageBox("00A4000002EF04--err");
		return;
	}

	re=Excute("00B20104BB",resp);
	if (re!=0)
	{
		MessageBox("00B20104BB--err");
		return;
	}

	memcpy(UserData1,resp+(6*2),0x75*2);     // 234
	memcpy(UserData2,resp+(0x7B*2),0x40*2);  // 128
	memcpy(UserData3,UserData1+(0x35*2),0x40*2); //128

	memset(cmd,0,200);
	memcpy(cmd,"8075000040",10);
	memcpy(cmd+10,EsamData1,128);
	re=ExcutePSAM(cmd,resp);
	if (re!=0)
	{
		MessageBox("SAM-8075000040--err");
		return;
	}


	re=ExcutePSAM("807B00001031323334353637383132333435363738",resp);
	if (re!=0)
	{
		MessageBox("SAM-807B000010--err");
		return;
	}

	memcpy(EsamData3,resp,64);//xx 64


	memset(cmd,0,200);
	memcpy(cmd,"807D00FF95",10);
	memcpy(cmd+10,EsamData3,64);
	memcpy(cmd+74,UserData1,234);
	memset(resp,0,1000);
	re=ExcutePSAM(cmd,resp);
	if (re!=0)
	{
		MessageBox("SAM-807D00FF95--err");
		return;
	}

	memcpy(EsamData4,resp,64);

	memset(cmd,0,1000);
	memcpy(cmd,"8079000060",10);
	memcpy(cmd+10,EsamData4,64);
	memcpy(cmd+74,UserData2,128);
	memset(resp,0,1000);
	re=ExcutePSAM(cmd,resp);
	if (re!=0)
	{
		MessageBox("SAM-8079000060--err");
		return;
	}

	memset(cmd,0,200);
	memcpy(cmd,"8075000040",10);
	memcpy(cmd+10,UserData3,128);
	memset(resp,0,1000);
	re=ExcutePSAM(cmd,resp);
	if (re!=0)
	{
		MessageBox("SAM-8075000040--err");
		return;
	}

	memset(cmd,0,200);
	memcpy(cmd,"8079000060",10);
	memcpy(cmd+10,EsamData0,64);
	memcpy(cmd+74,UserData5,128);
	memset(resp,0,1000);
	re=ExcutePSAM(cmd,resp);
	if (re!=0)
	{
		MessageBox("SAM-8079000060--err");
		return;
	}


	CString temp("");
	GetDlgItemText(IDC_RICHEDIT1,temp);
	str+="���ݼ�Ȩ�ɹ�";
	str+="\r\n";
	str+="----------------------------------";
	str+="\r\n";
	str+=temp;
	
	m_rich.SetWindowText(str);
	
}

void CEducationDemoDlg::OnIssueDocuments() 
{
	int re=0;
	char resp[1000]={0};
	unsigned char Resp[100]={0};
	char Random[50]={0};
	char Random2[50]={0};
	char RandomSAM[50]={0};
	char fsdata1[100]={0};
	char cmd[100]={0};
	char endata[100]={0};
	char endata_left[50]={0};
	char endata_right[50]={0};
	char endata_new[50]={0};


	re=OpenUSB();
	if (re!=0)
	{
		MessageBox("������δ���ӵ��Ի�Ƭ�ϵ�ʧ��");
		return;
	}


	re=Excute("00A4000000",resp);
	if (re!=0)
	{
		MessageBox("00A4000000--err");
		return;
	}

	re=Excute("00A4000002ADF0",resp);
	if (re!=0)
	{
		MessageBox("00A4000002ADF0--err");
		return;
	}

	re=Excute("00A4000002EF01",resp);
	if (re!=0)
	{
		MessageBox("00A4000002EF01--err");
		return;
	}

	re=Excute("0084000008",resp);
	if (re!=0)
	{
		MessageBox("0084000008--err");
		return;
	}

	memcpy(fsdata1,"1122334455667788",16);
	memcpy(Random,resp,16);

	
	re=ICC_Reader_pre_PowerOn(g_hReader,0x01,Resp);
	if (re<=0)
	{
		MessageBox("ESAM--err");
		return;
	}

	re=ExcutePSAM("0084000008",resp);
	if (re!=0)
	{
		MessageBox("SAM-0084000008--err");
		return;
	}
	memcpy(Random2,resp,16);

	re=ExcutePSAM("00A4000000",resp);
	if (re!=0)
	{
		MessageBox("SAM-00A4000000--err");
		return;
	}

	re=ExcutePSAM("00A4000002DF01",resp);
	if (re!=0)
	{
		MessageBox("SAM-00A4000002DF01--err");
		return;
	}

	memcpy(cmd,"801A270108",10);
	memcpy(cmd+10,fsdata1,16);
	re=ExcutePSAM(cmd,resp);
	if (re!=0)
	{
		MessageBox("SAM-801A270108--err");
		return;
	}

	memcpy(cmd,"80FA000010",10);
	memcpy(cmd+10,Random,16);
	memcpy(cmd+26,"0000000000000000",16);
	re=ExcutePSAM(cmd,resp);
	if (re!=0)
	{
		MessageBox("SAM-80FA000010--err");
		return;
	}

	memcpy(endata,resp,32);

	memset(cmd,0,100);

	memcpy(cmd,"801A000C10",10);
	memcpy(cmd+10,endata,32);
	re=ExcutePSAM(cmd,resp);
	if (re!=0)
	{
		MessageBox("SAM-801A000C10--err");
		return;
	}

	memset(cmd,0,100);
	memcpy(cmd,"80FA000010",10);
	memcpy(cmd+10,Random2,16);
	memcpy(cmd+26,"0000000000000000",16);
	re=ExcutePSAM(cmd,resp);
	if (re!=0)
	{
		MessageBox("SAM-80FA000010--err");
		return;
	}

	memcpy(endata_left,resp,16);
	memcpy(endata_right,resp+16,16);

	re=newhuo(endata_left,endata_right,endata_new);
	if(re!=0)
	{
		MessageBox("SAM-left_right--err");
		return;
	}

	memset(cmd,0,100);
	memcpy(cmd,"0082000A11",10);
	memcpy(cmd+10,endata_new,16);
	memcpy(cmd+26,Random2,16);
	memcpy(cmd+42,"00",2);
	re=Excute(cmd,resp);
	if (re!=0)
	{
		MessageBox("0082000A11--err");
		return;
	}

	
	re=Excute("00B0000000",resp);
	if (re!=0)
	{
		MessageBox("00B0000000--err");
		return;
	}

	CString str("");
	char c3f0105[50]={0};
	char c3f0205[50]={0};
	char c3fB201[50]={0};
	char c3f0301[50]={0};
	char c5a10[50]={0};
	char c3fb304[50]={0};
	char c3fb404[50]={0};
	char cBF0202[50]={0};

	memcpy(c3f0105,resp+6,10);
	memcpy(c3f0205,resp+22,10);
	memcpy(c3fB201,resp+38,2);
	memcpy(c3f0301,resp+46,2);
	memcpy(c5a10,resp+52,20);
	memcpy(c3fb304,resp+78,8);
	memcpy(c3fb404,resp+92,8);
	memcpy(cBF0202,resp+106,4);

	str+="����������:";
	str+=c3f0105;
	str+="\r\n";
	str+="Ӧ�����ͱ�ʶ:";
	str+=c3f0205;
	str+="\r\n";
	str+="Ӧ�ð汾:";
	str+=c3fB201;
	str+="\r\n";
	str+="�����ͱ�ʶ:";
	str+=c3f0301;
	str+="\r\n";
	str+="Ӧ�����к�:";
	str+=c5a10;
	str+="\r\n";
	str+="Ӧ����������:";
	str+=c3fb304;
	str+="\r\n";
	str+="Ӧ����Ч����:";
	str+=c3fb404;
	str+="\r\n";
	str+="�������Զ���FCI����:";
	str+=cBF0202;
	str+="\r\n";
	str+="----------------------------------";
	str+="\r\n";

	CString temp("");
	GetDlgItemText(IDC_RICHEDIT1,temp);
	str+=temp;
	str+="\r\n";
	m_rich.SetWindowText(str);


}

void CEducationDemoDlg::OnIssueDocumentsW() 
{
	CString str("");
	char c3f0105[50]={0};
	char c3f0205[50]={0};
	char c3fB201[50]={0};
	char c3f0301[50]={0};
	char c5a10[50]={0};
	char c3fb304[50]={0};
	char c3fb404[50]={0};
	char cBF0202[50]={0};
	
	GetDlgItemText(IDC_CardCode,str);
	memcpy(c3f0105,str,10);
	GetDlgItemText(IDC_AppLogo,str);
	memcpy(c3f0205,str,10);
	GetDlgItemText(IDC_AppEdition,str);
	memcpy(c3fB201,str,2);
	GetDlgItemText(IDC_CardLogo,str);
	memcpy(c3f0301,str,2);
	GetDlgItemText(IDC_CardNum,str);
	memcpy(c5a10,str,20);
	GetDlgItemText(IDC_OpenDate,str);
	memcpy(c3fb304,str,8);
	GetDlgItemText(IDC_EffectiveDate,str);
	memcpy(c3fb404,str,8);
	GetDlgItemText(IDC_FCI,str);
	memcpy(cBF0202,str,4);



	int re=0;
	char resp[1000]={0};
	unsigned char Resp[100]={0};
	char Random[50]={0};
	char Random2[50]={0};
	char RandomSAM[50]={0};
	char fsdata1[100]={0};
	char cmd[500]={0};
	char endata[100]={0};
	char endata_left[50]={0};
	char endata_right[50]={0};
	char endata_new[50]={0};
	char MAC[50]={0};


	re=OpenUSB();
	if (re!=0)
	{
		MessageBox("������δ���ӵ��Ի�Ƭ�ϵ�ʧ��");
		return;
	}


	re=Excute("00A4000000",resp);
	if (re!=0)
	{
		MessageBox("00A4000000--err");
		return;
	}

	re=Excute("00A4000002ADF0",resp);
	if (re!=0)
	{
		MessageBox("00A4000002ADF0--err");
		return;
	}

	re=Excute("00A4000002EF01",resp);
	if (re!=0)
	{
		MessageBox("00A4000002EF01--err");
		return;
	}

	re=Excute("0084000008",resp);
	if (re!=0)
	{
		MessageBox("0084000008--err");
		return;
	}

	memcpy(fsdata1,"1122334455667788",16);
	memcpy(Random,resp,16);

	
	re=ICC_Reader_pre_PowerOn(g_hReader,0x01,Resp);
	if (re<=0)
	{
		MessageBox("ESAM--err");
		return;
	}

	re=ExcutePSAM("0084000008",resp);
	if (re!=0)
	{
		MessageBox("SAM-0084000008--err");
		return;
	}
	memcpy(Random2,resp,16);

	re=ExcutePSAM("00A4000000",resp);
	if (re!=0)
	{
		MessageBox("SAM-00A4000000--err");
		return;
	}

	re=ExcutePSAM("00A4000002DF01",resp);
	if (re!=0)
	{
		MessageBox("SAM-00A4000002DF01--err");
		return;
	}

	memcpy(cmd,"801A270208",10);
	memcpy(cmd+10,fsdata1,16);
	re=ExcutePSAM(cmd,resp);
	if (re!=0)
	{
		MessageBox("SAM-801A270208--err");
		return;
	}

	memcpy(cmd,"80FA000010",10);
	memcpy(cmd+10,Random,16);
	memcpy(cmd+26,"0000000000000000",16);
	re=ExcutePSAM(cmd,resp);
	if (re!=0)
	{
		MessageBox("SAM-80FA000010--err");
		return;
	}

	memcpy(endata,resp,32);

	memset(cmd,0,100);

	memcpy(cmd,"801A000C10",10);
	memcpy(cmd+10,endata,32);
	re=ExcutePSAM(cmd,resp);
	if (re!=0)
	{
		MessageBox("SAM-801A000C10--err");
		return;
	}

	memset(cmd,0,100);
	memcpy(cmd,"80FA000010",10);
	memcpy(cmd+10,Random2,16);
	memcpy(cmd+26,"0000000000000000",16);
	re=ExcutePSAM(cmd,resp);
	if (re!=0)
	{
		MessageBox("SAM-80FA000010--err");
		return;
	}

	memcpy(endata_left,resp,16);
	memcpy(endata_right,resp+16,16);

	re=newhuo(endata_left,endata_right,endata_new);
	if(re!=0)
	{
		MessageBox("SAM-left_right--err");
		return;
	}

	memset(cmd,0,100);
	memcpy(cmd,"0082000B11",10);
	memcpy(cmd+10,endata_new,16);
	memcpy(cmd+26,Random2,16);
	memcpy(cmd+42,"00",2);
	re=Excute(cmd,resp);
	if (re!=0)
	{
		MessageBox("0082000A11--err");
		return;
	}

	re=Excute("0084000008",resp);
	if (re!=0)
	{
		MessageBox("0084000008--err");
		return;
	}
	
	memcpy(Random2,resp,16);

	memset(cmd,0,100);
	memcpy(cmd,"801A280108",10);
	memcpy(cmd+10,fsdata1,16);
	re=ExcutePSAM(cmd,resp);
	if (re!=0)
	{
		MessageBox("SAM-801A280108--err");
		return;
	}

	memset(cmd,0,100);
	memcpy(cmd,"80FA000010",10);
	memcpy(cmd+10,Random2,16);
	memcpy(cmd+26,"0000000000000000",16);
	re=ExcutePSAM(cmd,resp);
	if (re!=0)
	{
		MessageBox("SAM-80FA000010--err");
		return;
	}

	memcpy(endata,resp,32);

	memset(cmd,0,100);
	memcpy(cmd,"801A000C10",10);
	memcpy(cmd+10,endata,32);
	re=ExcutePSAM(cmd,resp);
	if (re!=0)
	{
		MessageBox("SAM-801A000C10--err");
		return;
	}

	memset(cmd,0,100);
	memcpy(cmd,"80FA01005004D6000043",20);
	memcpy(cmd+20,"3F010501020304053F020501020304053FB201013F0301005A0A201503161614350000373FB304119502033FB40411960203BF0C0201020000000000012345",126);
//������д������
	memcpy(cmd+26,c3f0105,10);
	memcpy(cmd+42,c3f0205,10);
	memcpy(cmd+58,c3fB201,2);
	memcpy(cmd+66,c3f0301,2);
	memcpy(cmd+72,c5a10,20);
	memcpy(cmd+98,c3fb304,8);
	memcpy(cmd+112,c3fb404,8);
	memcpy(cmd+126,cBF0202,4);

	memcpy(cmd+146,"800000000000000000000000",24);
	re=ExcutePSAM(cmd,resp);
	if (re!=0)
	{
		MessageBox("SAM-80FA010050--err");
		return;
	}

	memcpy(MAC,resp,8);

	memset(cmd,0,200);
	memcpy(cmd,"04D6000043",10);
	memcpy(cmd+10,"3F010501020304053F020501020304053FB201013F0301005A0A201503161614350000373FB304119502033FB40411960203BF0C0201020000000000012345",126);

	memcpy(cmd+16,c3f0105,10);
	memcpy(cmd+32,c3f0205,10);
	memcpy(cmd+48,c3fB201,2);
	memcpy(cmd+56,c3f0301,2);
	memcpy(cmd+62,c5a10,20);
	memcpy(cmd+88,c3fb304,8);
	memcpy(cmd+102,c3fb404,8);
	memcpy(cmd+116,cBF0202,4);

	memcpy(cmd+136,MAC,8);
	re=Excute(cmd,resp);
	if (re!=0)
	{
		MessageBox("04D6000043--err");
		return;
	}

	CString temp("");
	GetDlgItemText(IDC_RICHEDIT1,temp);
	str+="�����ļ�д��ɹ�";
	str+="\r\n";
	str+="----------------------------------";
	str+="\r\n";
	str+=temp;
	
	m_rich.SetWindowText(str);

}

void CEducationDemoDlg::OnCardAuthentication() 
{
	CString spin("");
	char cpin[100]={0};
	char ch[50]={0};
	GetDlgItemText(IDC_PIN,spin);
	if(spin.GetLength()!=6)
	{
		MessageBox("PIN���ȴ���");
		return ;
	}
	memcpy(ch,spin,6);
	for (int i=0;i<6;i++)
	{
		sprintf(cpin+2*i,"%02X",ch[i]);
	}

	int re=0;
	char resp[1000]={0};
	unsigned char Resp[100]={0};
	char Random[50]={0};
	char Random2[50]={0};
	char RandomSAM[50]={0};
	char fsdata1[100]={0};
	char fsdata2[100]={0};
	char cmd[1000]={0};
	char endata[100]={0};
	char endata_left[50]={0};
	char endata_right[50]={0};
	char endata_new[50]={0};
	char MAC[50]={0};
	char IDNum[100]={0};
	char CardNum[100]={0};
	char UserData0[500]={0};
	char UserData1[500]={0};
	char UserData2[500]={0};
	char UserData3[500]={0};
	char UserData4[500]={0};
	char UserData5[500]={0};
	char EsamData0[500]={0};
	char EsamData1[500]={0};
	char EsamData2[500]={0};
	char EsamData3[500]={0};
	char EsamData4[500]={0};

	CString str("");

	re=OpenUSB();
	if (re!=0)
	{
		MessageBox("������δ���ӵ��Ի�Ƭ�ϵ�ʧ��");
		return;
	}


	re=Excute("00A4000000",resp);
	if (re!=0)
	{
		MessageBox("00A4000000--err");
		return;
	}
	
	re=Excute("00A4000002ADF3",resp);
	if (re!=0)
	{
		MessageBox("00A4000002ADF3--err");
		return;
	}

	memcpy(cmd,"0020000006",10);
	memcpy(cmd+10,cpin,12);
	re=Excute(cmd,resp);
	if (re!=0)
	{
		spin.Format("%d 00200000--err",re);
		MessageBox(spin);
		return;
	}

	re=Excute("00A4000000",resp);
	if (re!=0)
	{
		MessageBox("00A4000000--err");
		return;
	}
	
	re=Excute("00A4000002ADF0",resp);
	if (re!=0)
	{
		MessageBox("00A4000002ADF0--err");
		return;
	}

	re=Excute("00A4000002EF02",resp);
	if (re!=0)
	{
		MessageBox("00A4000002EF02--err");
		return;
	}
	
	re=Excute("0084000008",resp);
	if (re!=0)
	{
		MessageBox("0084000008--err");
		return;
	}

	memcpy(fsdata1,"1122334455667788",16);
	memcpy(fsdata2,resp,16);

	re=ICC_Reader_pre_PowerOn(g_hReader,0x01,Resp);
	if (re<=0)
	{
		MessageBox("ESAM--err");
		return;
	}

	re=ExcutePSAM("0084000008",resp);
	if (re!=0)
	{
		MessageBox("SAM-0084000008--err");
		return;
	}
	memcpy(Random,resp,16);
	
	re=ExcutePSAM("00A4000000",resp);
	if (re!=0)
	{
		MessageBox("SAM-00A4000000--err");
		return;
	}
	
	re=ExcutePSAM("00A4000002DF01",resp);
	if (re!=0)
	{
		MessageBox("SAM-00A4000002DF01--err");
		return;
	}


	memcpy(cmd,"801A270108",10);
	memcpy(cmd+10,fsdata1,16);
	re=ExcutePSAM(cmd,resp);
	if (re!=0)
	{
		MessageBox("SAM-801A270108--err");
		return;
	}
	
	memcpy(cmd,"80FA000010",10);
	memcpy(cmd+10,fsdata2,16);
	memcpy(cmd+26,"0000000000000000",16);
	re=ExcutePSAM(cmd,resp);
	if (re!=0)
	{
		MessageBox("SAM-80FA000010--err");
		return;
	}
	
	memcpy(endata,resp,32);
	
	memset(cmd,0,100);
	
	memcpy(cmd,"801A000C10",10);
	memcpy(cmd+10,endata,32);
	re=ExcutePSAM(cmd,resp);
	if (re!=0)
	{
		MessageBox("SAM-801A000C10--err");
		return;
	}
	
	memset(cmd,0,100);
	memcpy(cmd,"80FA000010",10);
	memcpy(cmd+10,Random,16);
	memcpy(cmd+26,"0000000000000000",16);
	re=ExcutePSAM(cmd,resp);
	if (re!=0)
	{
		MessageBox("SAM-80FA000010--err");
		return;
	}
	
	memcpy(endata_left,resp,16);
	memcpy(endata_right,resp+16,16);
	
	re=newhuo(endata_left,endata_right,endata_new);
	if(re!=0)
	{
		MessageBox("SAM-left_right--err");
		return;
	}
	
	memset(cmd,0,100);
	memcpy(cmd,"0082000A11",10);
	memcpy(cmd+10,endata_new,16);
	memcpy(cmd+26,Random,16);
	memcpy(cmd+42,"00",2);
	re=Excute(cmd,resp);
	if (re!=0)
	{
		MessageBox("0082000A11--err");
		return;
	}
	
	re=Excute("00B000910D",resp);
	if (re!=0)
	{
		MessageBox("00B000910D--err");
		return;
	}
	memcpy(IDNum,resp+6,20);  //��ý���������ʶ���

	str+="��ý���������ʶ���:";
	str+=IDNum;
	str+="\r\n";

	re=Excute("00A4000002EF01",resp);
	if (re!=0)
	{
		MessageBox("00A4000002EF01--err");
		return;
	}

	re=Excute("00B000180C",resp);
	if (re!=0)
	{
		MessageBox("00B000180C--err");
		return;
	}
	memcpy(CardNum,resp+4,20);
	str+="���Ӧ�����к�:";
	str+=CardNum;
	str+="\r\n";

	re=ExcutePSAM("0084000008",resp);
	if (re!=0)
	{
		MessageBox("0084000008--err");
		return;
	}
	memcpy(Random,resp,16);

	re=Excute("00A4000000",resp);
	if (re!=0)
	{
		MessageBox("00A4000000--err");
		return;
	}
	
	re=Excute("00A4000002ADF3",resp);
	if (re!=0)
	{
		MessageBox("00A4000002ADF3--err");
		return;
	}

	memset(cmd,0,200);
	memcpy(cmd,"0089000008",10);
	memcpy(cmd+10,Random,16);
	re=Excute(cmd,resp);
	if (re!=0)
	{
		MessageBox("00A4000002ADF3--err");
		return;
	}

	memcpy(UserData4,resp+2,14);
	memcpy(UserData5,resp+0x28*2,0x40*2); //128

	memset(cmd,0,200);
	memcpy(cmd,"807D00FF19",10);
	memcpy(cmd+10,UserData4,14);
	memcpy(cmd+24,CardNum,20);
	memcpy(cmd+44,Random,16);
	memset(resp,0,1000);
	re=ExcutePSAM(cmd,resp);
	if (re!=0)
	{
		MessageBox("SAM-807D00FF19--err");
		return;
	}

	memcpy(EsamData0,resp,64);//xx 64

	re=ExcutePSAM("00A4000000",resp);
	if (re!=0)
	{
		MessageBox("SAM-00A4000000--err");
		return;
	}
	
	re=ExcutePSAM("00A4000002DF01",resp);
	if (re!=0)
	{
		MessageBox("SAM-00A4000002DF01--err");
		return;
	}

	re=ExcutePSAM("00A40000020004",resp);
	if (re!=0)
	{
		MessageBox("SAM-00A40000020004--err");
		return;
	}

	re=ExcutePSAM("00B00000F0",resp);
	if (re!=0)
	{
		MessageBox("SAM-00B00000F0--err");
		return;
	}

	memcpy(EsamData1,resp+(0x9C*2),0x40*2);//128

	memset(resp,0,1000);
	re=ExcutePSAM("00B000F0A3",resp);
	if (re!=0)
	{
		MessageBox("SAM-00B000F0A3--err");
		return;
	}

	memcpy(EsamData2,resp,326);  //xx 326

	re=Excute("00A4000002ADF3",resp);
	if (re!=0)
	{
		MessageBox("00A4000002ADF3--err");
		return;
	}


	re=Excute("00A4000002EF04",resp);
	if (re!=0)
	{
		MessageBox("00A4000002EF04--err");
		return;
	}

	re=Excute("00B20104BB",resp);
	if (re!=0)
	{
		MessageBox("00B20104BB--err");
		return;
	}

	memcpy(UserData1,resp+(6*2),0x75*2);     // 234
	memcpy(UserData2,resp+(0x7B*2),0x40*2);  // 128
	memcpy(UserData3,UserData1+(0x35*2),0x40*2); //128

	memset(cmd,0,200);
	memcpy(cmd,"8075000040",10);
	memcpy(cmd+10,EsamData1,128);
	re=ExcutePSAM(cmd,resp);
	if (re!=0)
	{
		MessageBox("SAM-8075000040--err");
		return;
	}


	re=ExcutePSAM("807B00001031323334353637383132333435363738",resp);
	if (re!=0)
	{
		MessageBox("SAM-807B000010--err");
		return;
	}

	memcpy(EsamData3,resp,64);//xx 64


	memset(cmd,0,200);
	memcpy(cmd,"807D00FF95",10);
	memcpy(cmd+10,EsamData3,64);
	memcpy(cmd+74,UserData1,234);
	memset(resp,0,1000);
	re=ExcutePSAM(cmd,resp);
	if (re!=0)
	{
		MessageBox("SAM-807D00FF95--err");
		return;
	}

	memcpy(EsamData4,resp,64);

	memset(cmd,0,1000);
	memcpy(cmd,"8079000060",10);
	memcpy(cmd+10,EsamData4,64);
	memcpy(cmd+74,UserData2,128);
	memset(resp,0,1000);
	re=ExcutePSAM(cmd,resp);
	if (re!=0)
	{
		MessageBox("SAM-8079000060--err");
		return;
	}

	memset(cmd,0,200);
	memcpy(cmd,"8075000040",10);
	memcpy(cmd+10,UserData3,128);
	memset(resp,0,1000);
	re=ExcutePSAM(cmd,resp);
	if (re!=0)
	{
		MessageBox("SAM-8075000040--err");
		return;
	}

	memset(cmd,0,200);
	memcpy(cmd,"8079000060",10);
	memcpy(cmd+10,EsamData0,64);
	memcpy(cmd+74,UserData5,128);
	memset(resp,0,1000);
	re=ExcutePSAM(cmd,resp);
	if (re!=0)
	{
		MessageBox("SAM-8079000060--err");
		return;
	}

	CString temp("");
	GetDlgItemText(IDC_RICHEDIT1,temp);
	str+="��Ƭ��Ȩ�ɹ�";
	str+="\r\n";
	str+="----------------------------------";
	str+="\r\n";
	str+=temp;
	m_rich.SetWindowText(str);

}
int CEducationDemoDlg::Exsten(char *EsamIndex,char *UserIndex)
{
	int re=0;
	char resp[1000]={0};
	unsigned char Resp[100]={0};
	char Random[50]={0};
	char Random2[50]={0};
	char RandomSAM[50]={0};
	char fsdata1[300]={0};
	char fsdata2[300]={0};
	char cmd[500]={0};
	char endata[100]={0};
	char endata_left[50]={0};
	char endata_right[50]={0};
	char endata_new[50]={0};
	char MAC[50]={0};


	re=Excute("0084000008",resp);
	if (re!=0)
	{
		MessageBox("0084000008--err");
		return-1;
	}

	memcpy(fsdata1,"1122334455667788",16);
	memcpy(fsdata2,resp,16);


	re=ExcutePSAM("0084000008",resp);
	if (re!=0)
	{
		MessageBox("SAM-0084000008--err");
		return-1;
	}
	memcpy(Random,resp,16);

	re=ExcutePSAM("00A4000000",resp);
	if (re!=0)
	{
		MessageBox("SAM-00A4000000--err");
		return-1;
	}

	re=ExcutePSAM("00A4000002DF01",resp);
	if (re!=0)
	{
		MessageBox("SAM-00A4000002DF01--err");
		return-1;
	}

	memcpy(cmd,"801A270208",10);
	memcpy(cmd+4,EsamIndex,4);
	memcpy(cmd+10,fsdata1,16);
	re=ExcutePSAM(cmd,resp);
	if (re!=0)
	{
		MessageBox("SAM-801A270208--err");
		return-1;
	}

	memcpy(cmd,"80FA000010",10);
	memcpy(cmd+10,fsdata2,16);
	memcpy(cmd+26,"0000000000000000",16);
	re=ExcutePSAM(cmd,resp);
	if (re!=0)
	{
		MessageBox("SAM-80FA000010--err");
		return-1;
	}

	memcpy(endata,resp,32);

	memset(cmd,0,100);

	memcpy(cmd,"801A000C10",10);
	memcpy(cmd+10,endata,32);
	re=ExcutePSAM(cmd,resp);
	if (re!=0)
	{
		MessageBox("SAM-801A000C10--err");
		return-1;
	}

	memset(cmd,0,100);
	memcpy(cmd,"80FA000010",10);
	memcpy(cmd+10,Random,16);
	memcpy(cmd+26,"0000000000000000",16);
	re=ExcutePSAM(cmd,resp);
	if (re!=0)
	{
		MessageBox("SAM-80FA000010--err");
		return-1;
	}

	memcpy(endata_left,resp,16);
	memcpy(endata_right,resp+16,16);

	re=newhuo(endata_left,endata_right,endata_new);
	if(re!=0)
	{
		MessageBox("SAM-left_right--err");
		return -1;
	}

	memset(cmd,0,100);
	memcpy(cmd,"0082000B11",10);
	memcpy(cmd+6,UserIndex,2);
	memcpy(cmd+10,endata_new,16);
	memcpy(cmd+26,Random,16);
	memcpy(cmd+42,"00",2);
	re=Excute(cmd,resp);
	if (re!=0)
	{
		MessageBox("0082000A11--err");
		return -1;
	}
	return 0;
}

int CEducationDemoDlg::AutP()
{
	CString spin("");
	char cpin[100]={0};
	char ch[50]={0};
	GetDlgItemText(IDC_PIN,spin);
	if(spin.GetLength()!=6)
	{
		MessageBox("PIN���ȴ���");
		return -1;
	}
	memcpy(ch,spin,6);
	for (int i=0;i<6;i++)
	{
		sprintf(cpin+2*i,"%02X",ch[i]);
	}

	int re=0;
	char resp[1000]={0};
	unsigned char Resp[100]={0};
	char Random[50]={0};
	char Random2[50]={0};
	char RandomSAM[50]={0};
	char fsdata1[100]={0};
	char fsdata2[100]={0};
	char cmd[1000]={0};
	char endata[100]={0};
	char endata_left[50]={0};
	char endata_right[50]={0};
	char endata_new[50]={0};
	char MAC[50]={0};
	char IDNum[100]={0};
	char CardNum[100]={0};
	char UserData0[500]={0};
	char UserData1[500]={0};
	char UserData2[500]={0};
	char UserData3[500]={0};
	char UserData4[500]={0};
	char UserData5[500]={0};
	char EsamData0[500]={0};
	char EsamData1[500]={0};
	char EsamData2[500]={0};
	char EsamData3[500]={0};
	char EsamData4[500]={0};

	CString str("");

	re=OpenUSB();
	if (re!=0)
	{
		MessageBox("������δ���ӵ��Ի�Ƭ�ϵ�ʧ��");
		return-1;
	}


	re=Excute("00A4000000",resp);
	if (re!=0)
	{
		MessageBox("00A4000000--err");
		return-1;
	}
	
	re=Excute("00A4000002ADF3",resp);
	if (re!=0)
	{
		MessageBox("00A4000002ADF3--err");
		return-1;
	}

	memcpy(cmd,"0020000006",10);
	memcpy(cmd+10,cpin,12);
	re=Excute(cmd,resp);
	if (re!=0)
	{
		spin.Format("%d 00200000--err",re);
		MessageBox(spin);
		return-1;
	}

	re=Excute("00A4000000",resp);
	if (re!=0)
	{
		MessageBox("00A4000000--err");
		return-1;
	}
	
	re=Excute("00A4000002ADF0",resp);
	if (re!=0)
	{
		MessageBox("00A4000002ADF0--err");
		return-1;
	}

	re=Excute("00A4000002EF02",resp);
	if (re!=0)
	{
		MessageBox("00A4000002EF02--err");
		return-1;
	}
	
	re=Excute("0084000008",resp);
	if (re!=0)
	{
		MessageBox("0084000008--err");
		return-1;
	}

	memcpy(fsdata1,"1122334455667788",16);
	memcpy(fsdata2,resp,16);

	re=ICC_Reader_pre_PowerOn(g_hReader,0x01,Resp);
	if (re<=0)
	{
		MessageBox("ESAM--err");
		return-1;
	}

	re=ExcutePSAM("0084000008",resp);
	if (re!=0)
	{
		MessageBox("SAM-0084000008--err");
		return-1;
	}
	memcpy(Random,resp,16);
	
	re=ExcutePSAM("00A4000000",resp);
	if (re!=0)
	{
		MessageBox("SAM-00A4000000--err");
		return-1;
	}
	
	re=ExcutePSAM("00A4000002DF01",resp);
	if (re!=0)
	{
		MessageBox("SAM-00A4000002DF01--err");
		return-1;
	}


	memcpy(cmd,"801A270108",10);
	memcpy(cmd+10,fsdata1,16);
	re=ExcutePSAM(cmd,resp);
	if (re!=0)
	{
		MessageBox("SAM-801A270108--err");
		return-1;
	}
	
	memcpy(cmd,"80FA000010",10);
	memcpy(cmd+10,fsdata2,16);
	memcpy(cmd+26,"0000000000000000",16);
	re=ExcutePSAM(cmd,resp);
	if (re!=0)
	{
		MessageBox("SAM-80FA000010--err");
		return-1;
	}
	
	memcpy(endata,resp,32);
	
	memset(cmd,0,100);
	
	memcpy(cmd,"801A000C10",10);
	memcpy(cmd+10,endata,32);
	re=ExcutePSAM(cmd,resp);
	if (re!=0)
	{
		MessageBox("SAM-801A000C10--err");
		return-1;
	}
	
	memset(cmd,0,100);
	memcpy(cmd,"80FA000010",10);
	memcpy(cmd+10,Random,16);
	memcpy(cmd+26,"0000000000000000",16);
	re=ExcutePSAM(cmd,resp);
	if (re!=0)
	{
		MessageBox("SAM-80FA000010--err");
		return-1;
	}
	
	memcpy(endata_left,resp,16);
	memcpy(endata_right,resp+16,16);
	
	re=newhuo(endata_left,endata_right,endata_new);
	if(re!=0)
	{
		MessageBox("SAM-left_right--err");
		return-1;
	}
	
	memset(cmd,0,100);
	memcpy(cmd,"0082000A11",10);
	memcpy(cmd+10,endata_new,16);
	memcpy(cmd+26,Random,16);
	memcpy(cmd+42,"00",2);
	re=Excute(cmd,resp);
	if (re!=0)
	{
		MessageBox("0082000A11--err");
		return-1;
	}
	
	re=Excute("00B000910D",resp);
	if (re!=0)
	{
		MessageBox("00B000910D--err");
		return-1;
	}
	memcpy(IDNum,resp+6,20);  //��ý���������ʶ���

	str+="��ý���������ʶ���:";
	str+=IDNum;
	str+="\r\n";

	re=Excute("00A4000002EF01",resp);
	if (re!=0)
	{
		MessageBox("00A4000002EF01--err");
		return-1;
	}

	re=Excute("00B000180C",resp);
	if (re!=0)
	{
		MessageBox("00B000180C--err");
		return-1;
	}
	memcpy(CardNum,resp+4,20);
	str+="���Ӧ�����к�:";
	str+=CardNum;
	str+="\r\n";

	re=ExcutePSAM("0084000008",resp);
	if (re!=0)
	{
		MessageBox("0084000008--err");
		return-1;
	}
	memcpy(Random,resp,16);

	re=Excute("00A4000000",resp);
	if (re!=0)
	{
		MessageBox("00A4000000--err");
		return-1;
	}
	
	re=Excute("00A4000002ADF3",resp);
	if (re!=0)
	{
		MessageBox("00A4000002ADF3--err");
		return -1;
	}

	memset(cmd,0,200);
	memcpy(cmd,"0089000008",10);
	memcpy(cmd+10,Random,16);
	re=Excute(cmd,resp);
	if (re!=0)
	{
		MessageBox("00A4000002ADF3--err");
		return-1;
	}

	memcpy(UserData4,resp+2,14);
	memcpy(UserData5,resp+0x28*2,0x40*2); //128

	memset(cmd,0,200);
	memcpy(cmd,"807D00FF19",10);
	memcpy(cmd+10,UserData4,14);
	memcpy(cmd+24,CardNum,20);
	memcpy(cmd+44,Random,16);
	memset(resp,0,1000);
	re=ExcutePSAM(cmd,resp);
	if (re!=0)
	{
		MessageBox("SAM-807D00FF19--err");
		return-1;
	}

	memcpy(EsamData0,resp,64);//xx 64

	re=ExcutePSAM("00A4000000",resp);
	if (re!=0)
	{
		MessageBox("SAM-00A4000000--err");
		return-1;
	}
	
	re=ExcutePSAM("00A4000002DF01",resp);
	if (re!=0)
	{
		MessageBox("SAM-00A4000002DF01--err");
		return-1;
	}

	re=ExcutePSAM("00A40000020004",resp);
	if (re!=0)
	{
		MessageBox("SAM-00A40000020004--err");
		return-1;
	}

	re=ExcutePSAM("00B00000F0",resp);
	if (re!=0)
	{
		MessageBox("SAM-00B00000F0--err");
		return-1;
	}

	memcpy(EsamData1,resp+(0x9C*2),0x40*2);//128

	memset(resp,0,1000);
	re=ExcutePSAM("00B000F0A3",resp);
	if (re!=0)
	{
		MessageBox("SAM-00B000F0A3--err");
		return-1;
	}

	memcpy(EsamData2,resp,326);  //xx 326

	re=Excute("00A4000002ADF3",resp);
	if (re!=0)
	{
		MessageBox("00A4000002ADF3--err");
		return-1;
	}


	re=Excute("00A4000002EF04",resp);
	if (re!=0)
	{
		MessageBox("00A4000002EF04--err");
		return-1;
	}

	re=Excute("00B20104BB",resp);
	if (re!=0)
	{
		MessageBox("00B20104BB--err");
		return-1;
	}

	memcpy(UserData1,resp+(6*2),0x75*2);     // 234
	memcpy(UserData2,resp+(0x7B*2),0x40*2);  // 128
	memcpy(UserData3,UserData1+(0x35*2),0x40*2); //128

	memset(cmd,0,200);
	memcpy(cmd,"8075000040",10);
	memcpy(cmd+10,EsamData1,128);
	re=ExcutePSAM(cmd,resp);
	if (re!=0)
	{
		MessageBox("SAM-8075000040--err");
		return-1;
	}


	re=ExcutePSAM("807B00001031323334353637383132333435363738",resp);
	if (re!=0)
	{
		MessageBox("SAM-807B000010--err");
		return-1;
	}

	memcpy(EsamData3,resp,64);//xx 64


	memset(cmd,0,200);
	memcpy(cmd,"807D00FF95",10);
	memcpy(cmd+10,EsamData3,64);
	memcpy(cmd+74,UserData1,234);
	memset(resp,0,1000);
	re=ExcutePSAM(cmd,resp);
	if (re!=0)
	{
		MessageBox("SAM-807D00FF95--err");
		return-1;
	}

	memcpy(EsamData4,resp,64);

	memset(cmd,0,1000);
	memcpy(cmd,"8079000060",10);
	memcpy(cmd+10,EsamData4,64);
	memcpy(cmd+74,UserData2,128);
	memset(resp,0,1000);
	re=ExcutePSAM(cmd,resp);
	if (re!=0)
	{
		MessageBox("SAM-8079000060--err");
		return-1;
	}

	memset(cmd,0,200);
	memcpy(cmd,"8075000040",10);
	memcpy(cmd+10,UserData3,128);
	memset(resp,0,1000);
	re=ExcutePSAM(cmd,resp);
	if (re!=0)
	{
		MessageBox("SAM-8075000040--err");
		return -1;
	}

	memset(cmd,0,200);
	memcpy(cmd,"8079000060",10);
	memcpy(cmd+10,EsamData0,64);
	memcpy(cmd+74,UserData5,128);
	memset(resp,0,1000);
	re=ExcutePSAM(cmd,resp);
	if (re!=0)
	{
		MessageBox("SAM-8079000060--err");
		return -1;
	}

	return 0;
}
void CEducationDemoDlg::OnSchoolSet() 
{
	CString str("");
	char statecode[100]={0};
	char semester[100]={0};
	char effectivedate[100]={0};
	char setdate[100]={0};
	GetDlgItemText(IDC_StateCode,str);
	memcpy(statecode,str,2);
	GetDlgItemText(IDC_Semester,str);
	memcpy(semester,str,4);
	GetDlgItemText(IDC_EffectiveDate5,str);
	memcpy(effectivedate,str,8);
	GetDlgItemText(IDC_SetDate,str);
	memcpy(setdate,str,8);


	int ret=AutP();
	if (ret!=0)
	{
		return ;
	}

	int re=0;
	char resp[1000]={0};
	unsigned char Resp[100]={0};
	char Random[50]={0};
	char Random2[50]={0};
	char RandomSAM[50]={0};
	char fsdata1[100]={0};
	char fsdata2[100]={0};
	char cmd[500]={0};
	char endata[100]={0};
	char endata_left[50]={0};
	char endata_right[50]={0};
	char endata_new[50]={0};
	char MAC[50]={0};

	re=Excute("00A4000000",resp);
	if (re!=0)
	{
		MessageBox("00A4000000--err");
		return;
	}
	
	re=Excute("00A4000002ADF1",resp);
	if (re!=0)
	{
		MessageBox("00A4000002ADF1--err");
		return;
	}

	re=Excute("00A4000002EF03",resp);
	if (re!=0)
	{
		MessageBox("00A4000002EF03--err");
		return;
	}

	re=Excute("0084000008",resp);
	if (re!=0)
	{
		MessageBox("0084000008--err");
		return;
	}

	memcpy(fsdata1,"1122334455667788",16);
	memcpy(fsdata2,resp,16);

	
	re=ExcutePSAM("0084000008",resp);
	if (re!=0)
	{
		MessageBox("SAM-0084000008--err");
		return;
	}
	memcpy(Random,resp,16);

	re=ExcutePSAM("00A4000000",resp);
	if (re!=0)
	{
		MessageBox("00A4000000--err");
		return;
	}
	
	re=ExcutePSAM("00A4000002DF01",resp);
	if (re!=0)
	{
		MessageBox("00A4000002ADF1--err");
		return;
	}

	

	memcpy(cmd,"801A270408",10);
	memcpy(cmd+10,fsdata1,16);
	re=ExcutePSAM(cmd,resp);
	if (re!=0)
	{
		MessageBox("SAM-801A270108--err");
		return;
	}
	
	memcpy(cmd,"80FA000010",10);
	memcpy(cmd+10,fsdata2,16);
	memcpy(cmd+26,"0000000000000000",16);
	re=ExcutePSAM(cmd,resp);
	if (re!=0)
	{
		MessageBox("SAM-80FA000010--err");
		return;
	}
	
	memcpy(endata,resp,32);
	
	memset(cmd,0,100);
	
	memcpy(cmd,"801A000C10",10);
	memcpy(cmd+10,endata,32);
	re=ExcutePSAM(cmd,resp);
	if (re!=0)
	{
		MessageBox("SAM-801A000C10--err");
		return;
	}
	
	memset(cmd,0,100);
	memcpy(cmd,"80FA000010",10);
	memcpy(cmd+10,Random,16);
	memcpy(cmd+26,"0000000000000000",16);
	re=ExcutePSAM(cmd,resp);
	if (re!=0)
	{
		MessageBox("SAM-80FA000010--err");
		return;
	}
	
	memcpy(endata_left,resp,16);
	memcpy(endata_right,resp+16,16);
	
	re=newhuo(endata_left,endata_right,endata_new);
	if(re!=0)
	{
		MessageBox("SAM-left_right--err");
		return;
	}
	
	memset(cmd,0,100);
	memcpy(cmd,"0082000B11",10);
	memcpy(cmd+10,endata_new,16);
	memcpy(cmd+26,Random,16);
	memcpy(cmd+42,"00",2);
	re=Excute(cmd,resp);
	if (re!=0)
	{
		MessageBox("0082000A11--err");
		return;
	}
	
	
	re=Excute("0084000008",resp);
	if (re!=0)
	{
		MessageBox("0084000008--err");
		return;
	}

	memcpy(Random,resp,16);

	memset(cmd,0,100);
	memcpy(cmd,"801A280208",10);
	memcpy(cmd+10,fsdata1,16);
	re=ExcutePSAM(cmd,resp);
	if (re!=0)
	{
		MessageBox("SAM-801A280208--err");
		return;
	}

	memset(cmd,0,100);
	memcpy(cmd,"80FA000010",10);
	memcpy(cmd+10,Random,16);
	memcpy(cmd+26,"0000000000000000",16);
	re=ExcutePSAM(cmd,resp);
	if (re!=0)
	{
		MessageBox("SAM-80FA000010--err");
		return;
	}

	memcpy(endata,resp,32);

	memset(cmd,0,100);
	memcpy(cmd,"801A000C10",10);
	memcpy(cmd+10,endata,32);
	re=ExcutePSAM(cmd,resp);
	if (re!=0)
	{
		MessageBox("SAM-801A000C10--err");
		return;
	}

	memset(cmd,0,100);
	memcpy(cmd,"80FA01002004DC00031B",20);
	memcpy(cmd+20,"3F4401013F450200023F4604136403023F470412640301",46);

	memcpy(cmd+26,statecode,2);
	memcpy(cmd+34,semester,4);
	memcpy(cmd+44,effectivedate,8);
	memcpy(cmd+58,setdate,8);

	memcpy(cmd+66,"80000000",8);

	re=ExcutePSAM(cmd,resp);
	if (re!=0)
	{
		MessageBox("SAM-80FA010020--err");
		return;
	}

	memcpy(MAC,resp,8);

	memset(cmd,0,100);
	memcpy(cmd,"04DC00031B",10);
	memcpy(cmd+10,"3F4401013F450200023F4604136403023F470412640301",46);
	
	memcpy(cmd+16,statecode,2);
	memcpy(cmd+24,semester,4);
	memcpy(cmd+34,effectivedate,8);
	memcpy(cmd+48,setdate,8);
	
	memcpy(cmd+56,MAC,8);
	
	re=Excute(cmd,resp);
	if (re!=0)
	{
		MessageBox("SAM-04DC00031B--err");
		return;
	}

	CString temp("");
	GetDlgItemText(IDC_RICHEDIT1,temp);
	
	str+="ѧ��ע��ɹ�";
	str+="\r\n";
	str+="----------------------------------";
	str+="\r\n";
	str+=temp;
	m_rich.SetWindowText(str);

}

void CEducationDemoDlg::OnEatSet() 
{
	CString str("");
	char QLogo[100]={0};
	char AllTimes[100]={0};
	char OpenDate6[100]={0};
	char EndDate6[100]={0};
	char EatType[100]={0};
	GetDlgItemText(IDC_QLogo,str);
	memcpy(QLogo,str,2);
	GetDlgItemText(IDC_AllTimes,str);
	memcpy(AllTimes,str,4);
	GetDlgItemText(IDC_OpenDate6,str);
	memcpy(OpenDate6,str,8);
	GetDlgItemText(IDC_EndDate6,str);
	memcpy(EndDate6,str,8);
	GetDlgItemText(IDC_EatType,str);
	memcpy(EatType,str,8);


	int ret=AutP();
	if (ret!=0)
	{
		return ;
	}

	int re=0;
	char resp[1000]={0};
	unsigned char Resp[100]={0};
	char Random[50]={0};
	char Random2[50]={0};
	char RandomSAM[50]={0};
	char fsdata1[100]={0};
	char fsdata2[100]={0};
	char cmd[500]={0};
	char endata[100]={0};
	char endata_left[50]={0};
	char endata_right[50]={0};
	char endata_new[50]={0};
	char MAC[50]={0};

	re=Excute("00A4000000",resp);
	if (re!=0)
	{
		MessageBox("00A4000000--err");
		return;
	}
	
	re=Excute("00A4000002ADF1",resp);
	if (re!=0)
	{
		MessageBox("00A4000002ADF1--err");
		return;
	}

	re=Excute("00A4000002EF06",resp);
	if (re!=0)
	{
		MessageBox("00A4000002EF06--err");
		return;
	}

	re=Excute("0084000008",resp);
	if (re!=0)
	{
		MessageBox("0084000008--err");
		return;
	}

	memcpy(fsdata1,"1122334455667788",16);
	memcpy(fsdata2,resp,16);

	
	re=ExcutePSAM("0084000008",resp);
	if (re!=0)
	{
		MessageBox("SAM-0084000008--err");
		return;
	}
	memcpy(Random,resp,16);

	re=ExcutePSAM("00A4000000",resp);
	if (re!=0)
	{
		MessageBox("00A4000000--err");
		return;
	}
	
	re=ExcutePSAM("00A4000002DF01",resp);
	if (re!=0)
	{
		MessageBox("00A4000002ADF1--err");
		return;
	}

	

	memcpy(cmd,"801A270408",10);
	memcpy(cmd+10,fsdata1,16);
	re=ExcutePSAM(cmd,resp);
	if (re!=0)
	{
		MessageBox("SAM-801A270108--err");
		return;
	}
	
	memcpy(cmd,"80FA000010",10);
	memcpy(cmd+10,fsdata2,16);
	memcpy(cmd+26,"0000000000000000",16);
	re=ExcutePSAM(cmd,resp);
	if (re!=0)
	{
		MessageBox("SAM-80FA000010--err");
		return;
	}
	
	memcpy(endata,resp,32);
	
	memset(cmd,0,100);
	
	memcpy(cmd,"801A000C10",10);
	memcpy(cmd+10,endata,32);
	re=ExcutePSAM(cmd,resp);
	if (re!=0)
	{
		MessageBox("SAM-801A000C10--err");
		return;
	}
	
	memset(cmd,0,100);
	memcpy(cmd,"80FA000010",10);
	memcpy(cmd+10,Random,16);
	memcpy(cmd+26,"0000000000000000",16);
	re=ExcutePSAM(cmd,resp);
	if (re!=0)
	{
		MessageBox("SAM-80FA000010--err");
		return;
	}
	
	memcpy(endata_left,resp,16);
	memcpy(endata_right,resp+16,16);
	
	re=newhuo(endata_left,endata_right,endata_new);
	if(re!=0)
	{
		MessageBox("SAM-left_right--err");
		return;
	}
	
	memset(cmd,0,100);
	memcpy(cmd,"0082000B11",10);
	memcpy(cmd+10,endata_new,16);
	memcpy(cmd+26,Random,16);
	memcpy(cmd+42,"00",2);
	re=Excute(cmd,resp);
	if (re!=0)
	{
		MessageBox("0082000A11--err");
		return;
	}
	
	
	re=Excute("0084000008",resp);
	if (re!=0)
	{
		MessageBox("0084000008--err");
		return;
	}

	memcpy(Random,resp,16);

	memset(cmd,0,100);
	memcpy(cmd,"801A280208",10);
	memcpy(cmd+10,fsdata1,16);
	re=ExcutePSAM(cmd,resp);
	if (re!=0)
	{
		MessageBox("SAM-801A280208--err");
		return;
	}

	memset(cmd,0,100);
	memcpy(cmd,"80FA000010",10);
	memcpy(cmd+10,Random,16);
	memcpy(cmd+26,"0000000000000000",16);
	re=ExcutePSAM(cmd,resp);
	if (re!=0)
	{
		MessageBox("SAM-80FA000010--err");
		return;
	}

	memcpy(endata,resp,32);

	memset(cmd,0,100);
	memcpy(cmd,"801A000C10",10);
	memcpy(cmd+10,endata,32);
	re=ExcutePSAM(cmd,resp);
	if (re!=0)
	{
		MessageBox("SAM-801A000C10--err");
		return;
	}

	memset(cmd,0,100);
	memcpy(cmd,"80FA01003004D6000022",20);
	memcpy(cmd+20,"3F7501023F4804198312023F4904198412023F760200013F770400000002",60);

	memcpy(cmd+26,QLogo,2);
	memcpy(cmd+34,OpenDate6,8);
	memcpy(cmd+48,EndDate6,8);
	memcpy(cmd+62,AllTimes,4);
	memcpy(cmd+72,EatType,8);

	memcpy(cmd+80,"80000000000000000000000000",26);

	re=ExcutePSAM(cmd,resp);
	if (re!=0)
	{
		MessageBox("SAM-80FA010030--err");
		return;
	}

	memcpy(MAC,resp,8);

	memset(cmd,0,100);
	memcpy(cmd,"04D6000022",10);
	memcpy(cmd+10,"3F7501023F4804198312023F4904198412023F760200013F770400000002",60);

	memcpy(cmd+16,QLogo,2);
	memcpy(cmd+24,OpenDate6,8);
	memcpy(cmd+38,EndDate6,8);
	memcpy(cmd+52,AllTimes,4);
	memcpy(cmd+62,EatType,8);
	
	memcpy(cmd+70,MAC,8);
	
	re=Excute(cmd,resp);
	if (re!=0)
	{
		MessageBox("SAM-04DC00031B--err");
		return;
	}

	CString temp("");
	GetDlgItemText(IDC_RICHEDIT1,temp);
	
	str+="Ӫ�����ʸ���³ɹ�";
	str+="\r\n";
	str+="----------------------------------";
	str+="\r\n";
	str+=temp;
	m_rich.SetWindowText(str);
	
}

void CEducationDemoDlg::OnUseSet() 
{
	CString str("");
	char SerialNum[100]={0};
	char LastUseTime[100]={0};

	GetDlgItemText(IDC_SerialNum,str);
	memcpy(SerialNum,str,4);
	GetDlgItemText(IDC_LastUseTime,str);
	memcpy(LastUseTime,str,14);



	int ret=AutP();
	if (ret!=0)
	{
		return ;
	}

	int re=0;
	char resp[1000]={0};
	unsigned char Resp[100]={0};
	char Random[50]={0};
	char Random2[50]={0};
	char RandomSAM[50]={0};
	char fsdata1[100]={0};
	char fsdata2[100]={0};
	char cmd[500]={0};
	char endata[100]={0};
	char endata_left[50]={0};
	char endata_right[50]={0};
	char endata_new[50]={0};
	char MAC[50]={0};

	re=Excute("00A4000000",resp);
	if (re!=0)
	{
		MessageBox("00A4000000--err");
		return;
	}
	
	re=Excute("00A4000002ADF1",resp);
	if (re!=0)
	{
		MessageBox("00A4000002ADF1--err");
		return;
	}

	re=Excute("00A4000002EF07",resp);
	if (re!=0)
	{
		MessageBox("00A4000002EF07--err");
		return;
	}

	re=Excute("0084000008",resp);
	if (re!=0)
	{
		MessageBox("0084000008--err");
		return;
	}

	memcpy(fsdata1,"1122334455667788",16);
	memcpy(fsdata2,resp,16);

	
	re=ExcutePSAM("0084000008",resp);
	if (re!=0)
	{
		MessageBox("SAM-0084000008--err");
		return;
	}
	memcpy(Random,resp,16);

	re=ExcutePSAM("00A4000000",resp);
	if (re!=0)
	{
		MessageBox("00A4000000--err");
		return;
	}
	
	re=ExcutePSAM("00A4000002DF01",resp);
	if (re!=0)
	{
		MessageBox("00A4000002ADF1--err");
		return;
	}

	

	memcpy(cmd,"801A270408",10);
	memcpy(cmd+10,fsdata1,16);
	re=ExcutePSAM(cmd,resp);
	if (re!=0)
	{
		MessageBox("SAM-801A270108--err");
		return;
	}
	
	memcpy(cmd,"80FA000010",10);
	memcpy(cmd+10,fsdata2,16);
	memcpy(cmd+26,"0000000000000000",16);
	re=ExcutePSAM(cmd,resp);
	if (re!=0)
	{
		MessageBox("SAM-80FA000010--err");
		return;
	}
	
	memcpy(endata,resp,32);
	
	memset(cmd,0,100);
	
	memcpy(cmd,"801A000C10",10);
	memcpy(cmd+10,endata,32);
	re=ExcutePSAM(cmd,resp);
	if (re!=0)
	{
		MessageBox("SAM-801A000C10--err");
		return;
	}
	
	memset(cmd,0,100);
	memcpy(cmd,"80FA000010",10);
	memcpy(cmd+10,Random,16);
	memcpy(cmd+26,"0000000000000000",16);
	re=ExcutePSAM(cmd,resp);
	if (re!=0)
	{
		MessageBox("SAM-80FA000010--err");
		return;
	}
	
	memcpy(endata_left,resp,16);
	memcpy(endata_right,resp+16,16);
	
	re=newhuo(endata_left,endata_right,endata_new);
	if(re!=0)
	{
		MessageBox("SAM-left_right--err");
		return;
	}
	
	memset(cmd,0,100);
	memcpy(cmd,"0082000B11",10);
	memcpy(cmd+10,endata_new,16);
	memcpy(cmd+26,Random,16);
	memcpy(cmd+42,"00",2);
	re=Excute(cmd,resp);
	if (re!=0)
	{
		MessageBox("0082000A11--err");
		return;
	}
	
	
	re=Excute("0084000008",resp);
	if (re!=0)
	{
		MessageBox("0084000008--err");
		return;
	}

	memcpy(Random,resp,16);

	memset(cmd,0,100);
	memcpy(cmd,"801A280208",10);
	memcpy(cmd+10,fsdata1,16);
	re=ExcutePSAM(cmd,resp);
	if (re!=0)
	{
		MessageBox("SAM-801A280208--err");
		return;
	}

	memset(cmd,0,100);
	memcpy(cmd,"80FA000010",10);
	memcpy(cmd+10,Random,16);
	memcpy(cmd+26,"0000000000000000",16);
	re=ExcutePSAM(cmd,resp);
	if (re!=0)
	{
		MessageBox("SAM-80FA000010--err");
		return;
	}

	memcpy(endata,resp,32);

	memset(cmd,0,100);
	memcpy(cmd,"801A000C10",10);
	memcpy(cmd+10,endata,32);
	re=ExcutePSAM(cmd,resp);
	if (re!=0)
	{
		MessageBox("SAM-801A000C10--err");
		return;
	}

	memset(cmd,0,100);
	memcpy(cmd,"80FA01002004DC000313",20);
	memcpy(cmd+20,"3F780200023F790700000019870405",30);

	memcpy(cmd+26,SerialNum,4);
	memcpy(cmd+36,LastUseTime,14);

	memcpy(cmd+50,"800000000000000000000000",24);

	re=ExcutePSAM(cmd,resp);
	if (re!=0)
	{
		MessageBox("SAM-80FA010030--err");
		return;
	}

	memcpy(MAC,resp,8);

	memset(cmd,0,1000);
	memcpy(cmd,"04DC000313",10);
	memcpy(cmd+10,"3F780200023F790700000019870405",30);

	memcpy(cmd+16,SerialNum,4);
	memcpy(cmd+26,LastUseTime,14);
		
	memcpy(cmd+40,MAC,8);
	
	re=Excute(cmd,resp);
	if (re!=0)
	{
		MessageBox("04DC00031B--err");
		return;
	}

	CString temp("");
	GetDlgItemText(IDC_RICHEDIT1,temp);
	
	str+="������Ϣ׷�ӳɹ�";
	str+="\r\n";
	str+="----------------------------------";
	str+="\r\n";
	str+=temp;
	m_rich.SetWindowText(str);
	
}

void CEducationDemoDlg::OnAppLock() 
{
	int re=0;
	char resp[1000]={0};
	unsigned char Resp[100]={0};
	char Random[50]={0};
	char Random2[50]={0};
	char RandomSAM[50]={0};
	char fsdata1[500]={0};
	char fsdata2[500]={0};
	char cmd[500]={0};
	char endata[100]={0};
	char endata_left[50]={0};
	char endata_right[50]={0};
	char endata_new[50]={0};
	char MAC[50]={0};


	re=OpenUSB();
	if (re!=0)
	{
		MessageBox("������δ���ӵ��Ի�Ƭ�ϵ�ʧ��");
		return;
	}


	re=Excute("00A4000000",resp);
	if (re!=0)
	{
		MessageBox("00A4000000--err");
		return;
	}

	re=Excute("00A4000002ADF1",resp);
	if (re!=0)
	{
		MessageBox("00A4000002ADF1--err");
		return;
	}


	re=Excute("0084000008",resp);
	if (re!=0)
	{
		MessageBox("0084000008--err");
		return;
	}

	memcpy(fsdata1,"1122334455667788",16);
	memcpy(fsdata2,resp,16);

	
	re=ICC_Reader_pre_PowerOn(g_hReader,0x01,Resp);
	if (re<=0)
	{
		MessageBox("ESAM--err");
		return;
	}

	re=ExcutePSAM("0084000008",resp);
	if (re!=0)
	{
		MessageBox("SAM-0084000008--err");
		return;
	}
	memcpy(Random,resp,16);

	re=ExcutePSAM("00A4000000",resp);
	if (re!=0)
	{
		MessageBox("SAM-00A4000000--err");
		return;
	}

	re=ExcutePSAM("00A4000002DF01",resp);
	if (re!=0)
	{
		MessageBox("SAM-00A4000002DF01--err");
		return;
	}

	memcpy(cmd,"801A280208",10);
	memcpy(cmd+10,fsdata1,16);
	re=ExcutePSAM(cmd,resp);
	if (re!=0)
	{
		MessageBox("SAM-801A270208--err");
		return;
	}

	memcpy(cmd,"80FA000010",10);
	memcpy(cmd+10,fsdata2,16);
	memcpy(cmd+26,"0000000000000000",16);
	re=ExcutePSAM(cmd,resp);
	if (re!=0)
	{
		MessageBox("SAM-80FA000010--err");
		return;
	}

	memcpy(endata,resp,32);

	memset(cmd,0,100);

	memcpy(cmd,"801A000C10",10);
	memcpy(cmd+10,endata,32);
	re=ExcutePSAM(cmd,resp);
	if (re!=0)
	{
		MessageBox("SAM-801A000C10--err");
		return;
	}

	re=ExcutePSAM("80FA010010841E0000048000000000000000000000",resp);
	if (re!=0)
	{
		MessageBox("SAM-80FA010010--err");
		return;
	}

	memcpy(MAC,resp,8);

	memcpy(cmd,"841E000004",10);
	memcpy(cmd+10,MAC,8);
	re=Excute(cmd,resp);
	if (re!=0)
	{
		MessageBox("SAM-801A000C10--err");
		return;
	}


	re=Excute("00A4000000",resp);
	if (re!=0)
	{
		MessageBox("00A4000000--err");
		return;
	}
	
	re=Excute("00A4000002ADF1",resp);
	if (re!=0x6a81)//
	{
		MessageBox("00A4000002ADF1--err");
		return;
	}

	CString str("");
	CString temp("");
	GetDlgItemText(IDC_RICHEDIT1,temp);
	str+="Ӧ�������ɹ�";
	str+="\r\n";
	str+="----------------------------------";
	str+="\r\n";
	str+=temp;
	m_rich.SetWindowText(str);

}

void CEducationDemoDlg::OnAppUnlock() 
{
	int re=0;
	char resp[1000]={0};
	unsigned char Resp[100]={0};
	char Random[50]={0};
	char Random2[50]={0};
	char RandomSAM[50]={0};
	char fsdata1[500]={0};
	char fsdata2[500]={0};
	char cmd[500]={0};
	char endata[100]={0};
	char endata_left[50]={0};
	char endata_right[50]={0};
	char endata_new[50]={0};
	char MAC[50]={0};


	re=OpenUSB();
	if (re!=0)
	{
		MessageBox("������δ���ӵ��Ի�Ƭ�ϵ�ʧ��");
		return;
	}


	re=Excute("00A4000000",resp);
	if (re!=0)
	{
		MessageBox("00A4000000--err");
		return;
	}

	re=Excute("00A4000002ADF1",resp);
	if (re!=0x6a81)  //
	{
		MessageBox("��Ӧ��δ�����������������");
		return;
	}


	re=Excute("0084000008",resp);
	if (re!=0)
	{
		MessageBox("0084000008--err");
		return;
	}

	memcpy(fsdata1,"1122334455667788",16);
	memcpy(fsdata2,resp,16);

	
	re=ICC_Reader_pre_PowerOn(g_hReader,0x01,Resp);
	if (re<=0)
	{
		MessageBox("ESAM--err");
		return;
	}

	re=ExcutePSAM("0084000008",resp);
	if (re!=0)
	{
		MessageBox("SAM-0084000008--err");
		return;
	}
	memcpy(Random,resp,16);

	re=ExcutePSAM("00A4000000",resp);
	if (re!=0)
	{
		MessageBox("SAM-00A4000000--err");
		return;
	}

	re=ExcutePSAM("00A4000002DF01",resp);
	if (re!=0)
	{
		MessageBox("SAM-00A4000002DF01--err");
		return;
	}

	memcpy(cmd,"801A280208",10);
	memcpy(cmd+10,fsdata1,16);
	re=ExcutePSAM(cmd,resp);
	if (re!=0)
	{
		MessageBox("SAM-801A270208--err");
		return;
	}

	memcpy(cmd,"80FA000010",10);
	memcpy(cmd+10,fsdata2,16);
	memcpy(cmd+26,"0000000000000000",16);
	re=ExcutePSAM(cmd,resp);
	if (re!=0)
	{
		MessageBox("SAM-80FA000010--err");
		return;
	}

	memcpy(endata,resp,32);

	memset(cmd,0,100);

	memcpy(cmd,"801A000C10",10);
	memcpy(cmd+10,endata,32);
	re=ExcutePSAM(cmd,resp);
	if (re!=0)
	{
		MessageBox("SAM-801A000C10--err");
		return;
	}

	re=ExcutePSAM("80FA01001084180000048000000000000000000000",resp);
	if (re!=0)
	{
		MessageBox("SAM-80FA010010--err");
		return;
	}

	memcpy(MAC,resp,8);

	memcpy(cmd,"8418000004",10);
	memcpy(cmd+10,MAC,8);
	re=Excute(cmd,resp);
	if (re!=0)
	{
		MessageBox("SAM-801A000C10--err");
		return;
	}


	re=Excute("00A4000000",resp);
	if (re!=0)
	{
		MessageBox("00A4000000--err");
		return;
	}
	
	re=Excute("00A4000002ADF1",resp);
	if (re!=0)
	{
		MessageBox("00A4000002ADF1--err");
		return;
	}

	CString str("");
	CString temp("");
	GetDlgItemText(IDC_RICHEDIT1,temp);
	
	str+="Ӧ�ý����ɹ�";
	str+="\r\n";
	str+="----------------------------------";
	str+="\r\n";
	str+=temp;
	m_rich.SetWindowText(str);
	
}

void CEducationDemoDlg::OnChangePIN() 
{
	CString str("");
	char oldpin[100]={0};
	char newpin[100]={0};
	char ch[50]={0};
	GetDlgItemText(IDC_OldPin,str);
	if(str.GetLength()!=6)
	{
		MessageBox("OldPin���ȴ���");
		return ;
	}
	memcpy(ch,str,6);
	for (int i=0;i<6;i++)
	{
		sprintf(oldpin+2*i,"%02X",ch[i]);
	}
	GetDlgItemText(IDC_NewPin,str);
	if(str.GetLength()!=6)
	{
		MessageBox("NewPin���ȴ���");
		return ;
	}
	memcpy(ch,str,6);
	for (i=0;i<6;i++)
	{
		sprintf(newpin+2*i,"%02X",ch[i]);
	}


	int re=0;
	char resp[1000]={0};
	unsigned char Resp[100]={0};
	char Random[50]={0};
	char Random2[50]={0};
	char RandomSAM[50]={0};
	char fsdata1[500]={0};
	char fsdata2[500]={0};
	char cmd[500]={0};
	char endata[100]={0};
	char endata_left[50]={0};
	char endata_right[50]={0};
	char endata_new[50]={0};
	char MAC[50]={0};
	
	
	re=OpenUSB();
	if (re!=0)
	{
		MessageBox("������δ���ӵ��Ի�Ƭ�ϵ�ʧ��");
		return;
	}
	
	
	re=Excute("00A4000000",resp);
	if (re!=0)
	{
		MessageBox("00A4000000--err");
		return;
	}

	re=Excute("00A4000002ADF3",resp);
	if (re!=0)
	{
		MessageBox("00A4000002ADF3--err");
		return;
	}

	memcpy(cmd,"805E01000D",10);
	memcpy(cmd+10,oldpin,12);
	memcpy(cmd+22,"FF",2);
	memcpy(cmd+24,newpin,12);
	re=Excute(cmd,resp);
	if (re!=0)
	{
		MessageBox("805E01000D--err");
		if(re==0x6983)
			MessageBox("PIN������");
		return;
	}

	memcpy(cmd,"0020000006",10);
	memcpy(cmd+10,newpin,12);
	re=Excute(cmd,resp);
	if (re!=0)
	{
		MessageBox("newPIN--err");
		return;
	}


	CString temp("");
	GetDlgItemText(IDC_RICHEDIT1,temp);
	
	str+="�޸Ŀ���ɹ�";
	str+="\r\n";
	str+="----------------------------------";
	str+="\r\n";
	str+=temp;
	
	m_rich.SetWindowText(str);

	
}

void CEducationDemoDlg::OnUnlockPin() 
{
	int re=0;
	char resp[1000]={0};
	unsigned char Resp[100]={0};
	char Random[50]={0};
	char Random2[50]={0};
	char RandomSAM[50]={0};
	char fsdata1[500]={0};
	char fsdata2[500]={0};
	char cmd[500]={0};
	char endata[100]={0};
	char endata_left[50]={0};
	char endata_right[50]={0};
	char endata_new[50]={0};
	char MAC[50]={0};


	re=OpenUSB();
	if (re!=0)
	{
		MessageBox("������δ���ӵ��Ի�Ƭ�ϵ�ʧ��");
		return;
	}


	re=Excute("00A4000000",resp);
	if (re!=0)
	{
		MessageBox("00A4000000--err");
		return;
	}

	re=Excute("00A4000002ADF3",resp);
	if (re!=0)
	{
		return;
	}


	re=Excute("0084000008",resp);
	if (re!=0)
	{
		MessageBox("0084000008--err");
		return;
	}

	memcpy(fsdata1,"1122334455667788",16);
	memcpy(fsdata2,resp,16);

	
	re=ICC_Reader_pre_PowerOn(g_hReader,0x01,Resp);
	if (re<=0)
	{
		MessageBox("ESAM--err");
		return;
	}

	re=ExcutePSAM("0084000008",resp);
	if (re!=0)
	{
		MessageBox("SAM-0084000008--err");
		return;
	}
	memcpy(Random,resp,16);

	re=ExcutePSAM("00A4000000",resp);
	if (re!=0)
	{
		MessageBox("SAM-00A4000000--err");
		return;
	}

	re=ExcutePSAM("00A4000002DF01",resp);
	if (re!=0)
	{
		MessageBox("SAM-00A4000002DF01--err");
		return;
	}

	memcpy(cmd,"801A260108",10);
	memcpy(cmd+10,fsdata1,16);
	re=ExcutePSAM(cmd,resp);
	if (re!=0)
	{
		MessageBox("SAM-801A270208--err");
		return;
	}

	memcpy(cmd,"80FA000010",10);
	memcpy(cmd+10,fsdata2,16);
	memcpy(cmd+26,"0000000000000000",16);
	re=ExcutePSAM(cmd,resp);
	if (re!=0)
	{
		MessageBox("SAM-80FA000010--err");
		return;
	}

	memcpy(endata,resp,32);

	memset(cmd,0,100);

	memcpy(cmd,"801A000C10",10);
	memcpy(cmd+10,endata,32);
	re=ExcutePSAM(cmd,resp);
	if (re!=0)
	{
		MessageBox("SAM-801A000C10--err");
		return;
	}

	re=ExcutePSAM("80FA01001084240000048000000000000000000000",resp);
	if (re!=0)
	{
		MessageBox("SAM-80FA010010--err");
		return;
	}

	memcpy(MAC,resp,8);

	memcpy(cmd,"8424000004",10);
	memcpy(cmd+10,MAC,8);
	re=Excute(cmd,resp);
	if (re!=0)
	{
		MessageBox("8424000004--err");
		return;
	}


	re=Excute("0020000006313131313131",resp);
	if (re!=0)
	{
		MessageBox("0020--err");
		return;
	}


	CString str("");
	CString temp("");
	GetDlgItemText(IDC_RICHEDIT1,temp);
	str+="��������ɹ�";
	str+="\r\n";
	str+="----------------------------------";
	str+="\r\n";
	str+=temp;
	
	m_rich.SetWindowText(str);
}

void CEducationDemoDlg::OnClear() 
{
	m_rich.SetWindowText("");
}

void CEducationDemoDlg::OnReadADF() 
{
	CString str("");
	CString sData("");
	char cAdf[100]={0};
	GetDlgItemText(IDC_Read,str);
	memcpy(cAdf,str,4);
	int iAdf=(chartoint(cAdf[0])*16+chartoint(cAdf[1]))*256+chartoint(cAdf[2])*16+chartoint(cAdf[3]);

	int re=0;
	char resp[1000]={0};
	unsigned char Resp[100]={0};
	char Random[50]={0};
	char Random2[50]={0};
	char RandomSAM[50]={0};
	char fsdata1[500]={0};
	char fsdata2[500]={0};
	char cmd[500]={0};
	char endata[100]={0};
	char endata_left[50]={0};
	char endata_right[50]={0};
	char endata_new[50]={0};
	char MAC[50]={0};

	
	re=OpenUSB();
	if (re!=0)
	{
		MessageBox("������δ���ӵ��Ի�Ƭ�ϵ�ʧ��");
		return;
	}

	re=ICC_Reader_pre_PowerOn(g_hReader,0x01,Resp);
	if (re<=0)
	{
		MessageBox("ESAM--err");
		return;
	}

	re=Excute("00A4000000",resp);
	if (re!=0)
	{
		MessageBox("00A4000000--err");
		return;
	}

	memcpy(cmd,"00A4000002ADF0",14);
	memcpy(cmd+10,str,4);
	re=Excute(cmd,resp);
	if (re!=0)
	{
		MessageBox("00A4000000--err");
		return;
	}

	switch(iAdf)
	{
	case 0xADF0:
		{
			re=Exsten("2701","0A");
			if(re!=0)
			{
				MessageBox("�ⲿ��֤ʧ��");
				return ;
			}

			re=Excute("00A4000002EF01",resp);
			if (re!=0)
			{
				MessageBox("00A4000002EF01--err");
				return;
			}

			re=Excute("00B0000000",resp);
			if (re!=0)
			{
				MessageBox("00B0������Ϣ--err");
				return;
			}
			char cef01[300]={0};
			memcpy(cef01,resp,110);
			sData+="������������Ϣ:";
			sData+=cef01;
			sData+="\r\n";

			re=Excute("00A4000002EF02",resp);
			if (re!=0)
			{
				MessageBox("00A4000002EF02--err");
				return;
			}
			
		
			char cef02[8000]={0};
	
			re=Excute("00B0000000",resp);
			if (re!=0)
			{
				MessageBox("00B0���˻�����Ϣ--err");
				return;
			}
			
			strcpy(cef02,resp);
			sData+="���˻�����Ϣ:";
			sData+=cef02;
			sData+="\r\n";

			re=Excute("00A4000002EF03",resp);
			if (re!=0)
			{
				MessageBox("00A4000002EF03--err");
				return;
			}
			
			re=Excute("00B0000000",resp);
			if (re!=0)
			{
				MessageBox("00B0��Ƭ��Ϣ--err");
				return;
			}
			char cef03[10000]={0};
			strcpy(cef03,resp);
			sData+="��Ƭ��Ϣ:";
			sData+=cef03;
			sData+="\r\n";


			re=Excute("00A4000002EF04",resp);
			if (re!=0)
			{
				MessageBox("00A4000002EF04--err");
				return;
			}
			
			re=Excute("00B0000000",resp);
			if (re!=0)
			{
				MessageBox("00B0����������Ϣ--err");
				return;
			}
			char cef04[4000]={0};
			memcpy(cef04,resp,2088);
			sData+="����������Ϣ:";
			sData+=cef04;
			sData+="\r\n";

		}
		break;
	case 0xADF1:
		{
			re=Exsten("2703","0A");
			if(re!=0)
			{
				MessageBox("�ⲿ��֤ʧ��");
				return ;
			}
			
			re=Excute("00A4000002EF01",resp);
			if (re!=0)
			{
				MessageBox("00A4000002EF01--err");
				return;
			}
			
			re=Excute("00B0000000",resp);
			if (re!=0)
			{
				MessageBox("00B0������Ϣ�ļ�--err");
				return;
			}
			char cef01[3000]={0};
			strcpy(cef01,resp);
			sData+="������Ϣ�ļ�:";
			sData+=cef01;
			sData+="\r\n";
			
			re=Excute("00A4000002EF02",resp);
			if (re!=0)
			{
				MessageBox("00A4000002EF02--err");
				return;
			}
			
			
			char cef02[8000]={0};
			
			re=Excute("00B0000000",resp);
			if (re!=0)
			{
				MessageBox("00B0ѧ����Ϣ�ļ�--err");
				return;
			}
			
			strcpy(cef02,resp);
			sData+="ѧ����Ϣ�ļ�:";
			sData+=cef02;
			sData+="\r\n";
			
			re=Excute("00A4000002EF03",resp);
			if (re!=0)
			{
				MessageBox("00A4000002EF03--err");
				return;
			}
			
			re=Excute("00B2010400",resp);
			if (re!=0)
			{
				MessageBox("00B0ѧ��ע���ļ�--err");
				return;
			}
			char cef03[10000]={0};
			strcpy(cef03,resp);
			sData+="ѧ��ע���ļ�:";
			sData+=cef03;
			sData+="\r\n";
			
			
			re=Excute("00A4000002EF04",resp);
			if (re!=0)
			{
				MessageBox("00A4000002EF04--err");
				return;
			}
			
			re=Excute("00B0000000",resp);
			if (re!=0)
			{
				MessageBox("00B0���ʽ�����Ϣ--err");
				return;
			}
			char cef04[5000]={0};
			strcpy(cef04,resp);
			sData+="���ʽ�����Ϣ:";
			sData+=cef04;
			sData+="\r\n";

			re=Excute("00A4000002EF05",resp);
			if (re!=0)
			{
				MessageBox("00A4000002EF05--err");
				return;
			}
			
			re=Excute("00B2010400",resp);
			if (re!=0)
			{
				MessageBox("00B0ѧ����ѧ������Ϣ--err");
				return;
			}
			char cef05[5000]={0};
			strcpy(cef05,resp);
			sData+="ѧ����ѧ������Ϣ:";
			sData+=cef05;
			sData+="\r\n";

			re=Excute("00A4000002EF06",resp);
			if (re!=0)
			{
				MessageBox("00A4000002EF06--err");
				return;
			}
			
			re=Excute("00B0000000",resp);
			if (re!=0)
			{
				MessageBox("00B0Ӫ�����ʸ���Ϣ--err");
				return;
			}
			char cef06[5000]={0};
			strcpy(cef06,resp);
			sData+="Ӫ�����ʸ���Ϣ:";
			sData+=cef06;
			sData+="\r\n";

			re=Excute("00A4000002EF07",resp);
			if (re!=0)
			{
				MessageBox("00A4000002EF07--err");
				return;
			}
			
			re=Excute("00B2010400",resp);
			if (re!=0)
			{
				MessageBox("00B0Ӫ���������Ϣ--err");
				return;
			}
			char cef07[5000]={0};
			strcpy(cef07,resp);
			sData+="Ӫ���������Ϣ:";
			sData+=cef07;
			sData+="\r\n";
		}
		break;
	case 0xADF2:
		{
			re=Exsten("2705","0A");
			if(re!=0)
			{
				MessageBox("�ⲿ��֤ʧ��");
				return ;
			}
			
			re=Excute("00A4000002EF01",resp);
			if (re!=0)
			{
				MessageBox("00A4000002EF01--err");
				return;
			}
			
			re=Excute("00B2010400",resp);
			if (re!=0)
			{
				MessageBox("00B0��ҵ֤���ļ�--err");
				return;
			}
			char cef01[3000]={0};
			strcpy(cef01,resp);
			sData+="��ҵ֤���ļ�:";
			sData+=cef01;
			sData+="\r\n";
			
			re=Excute("00A4000002EF02",resp);
			if (re!=0)
			{
				MessageBox("00A4000002EF02--err");
				return;
			}
			
			
			char cef02[8000]={0};
			
			re=Excute("00B2010400",resp);
			if (re!=0)
			{
				MessageBox("00B0ѧλ֤���ļ�--err");
				return;
			}
			
			strcpy(cef02,resp);
			sData+="ѧλ֤���ļ�:";
			sData+=cef02;
			sData+="\r\n";
			
			re=Excute("00A4000002EF03",resp);
			if (re!=0)
			{
				MessageBox("00A4000002EF03--err");
				return;
			}
			
			re=Excute("00B2010400",resp);
			if (re!=0)
			{
				MessageBox("00B0�ʸ�ˮƽ��Ϣ--err");
				return;
			}
			char cef03[10000]={0};
			strcpy(cef03,resp);
			sData+="�ʸ�ˮƽ��Ϣ:";
			sData+=cef03;
			sData+="\r\n";
			
			
			re=Excute("00A4000002EF04",resp);
			if (re!=0)
			{
				MessageBox("00A4000002EF04--err");
				return;
			}
			
			re=Excute("00B2010400",resp);
			if (re!=0)
			{
				MessageBox("00B0���������Ϣ--err");
				return;
			}
			char cef04[5000]={0};
			strcpy(cef04,resp);
			sData+="���������Ϣ:";
			sData+=cef04;
			sData+="\r\n";

			re=Excute("00A4000002EF05",resp);
			if (re!=0)
			{
				MessageBox("00A4000002EF05--err");
				return;
			}
			
			re=Excute("00B0000000",resp);
			if (re!=0)
			{
				MessageBox("00B0ѧ���״ξ�ҵ��Ϣ--err");
				return;
			}
			char cef05[5000]={0};
			strcpy(cef05,resp);
			sData+="ѧ���״ξ�ҵ��Ϣ:";
			sData+=cef05;
			sData+="\r\n";

			re=Excute("00A4000002EF06",resp);
			if (re!=0)
			{
				MessageBox("00A4000002EF06--err");
				return;
			}
			
			re=Excute("00B2010400",resp);
			if (re!=0)
			{
				MessageBox("00B0����������Ϣ--err");
				return;
			}
			char cef06[5000]={0};
			strcpy(cef06,resp);
			sData+="����������Ϣ:";
			sData+=cef06;
			sData+="\r\n";
		}
		break;
	case 0xADF3:
		{
			re=Exsten("2707","0A");
			if(re!=0)
			{
				MessageBox("�ⲿ��֤ʧ��");
				return ;
			}
			
			re=Excute("00A4000002EF04",resp);
			if (re!=0)
			{
				MessageBox("00A4000002EF04--err");
				return;
			}
			
			re=Excute("00B2010400",resp);
			if (re!=0)
			{
				MessageBox("00B0����֤����Ϣ--err");
				return;
			}
			char cef04[5000]={0};
			strcpy(cef04,resp);
			sData+="����֤����Ϣ:";
			sData+=cef04;
			sData+="\r\n";

		}
		break;
	case 0xADF4:
		{
			re=Exsten("2709","0A");
			if(re!=0)
			{
				MessageBox("�ⲿ��֤ʧ��");
				return ;
			}
			
			re=Excute("00A4000002EF01",resp);
			if (re!=0)
			{
				MessageBox("00A4000002EF01--err");
				return;
			}
			
			re=Excute("00B0000000",resp);
			if (re!=0)
			{
				MessageBox("00B0�ط�����Ӧ����Ϣ--err");
				return;
			}
			char cef01[3000]={0};
			strcpy(cef01,resp);
			sData+="�ط�����Ӧ����Ϣ:";
			sData+=cef01;
			sData+="\r\n";
			
			re=Excute("00A4000002EF02",resp);
			if (re!=0)
			{
				MessageBox("00A4000002EF02--err");
				return;
			}
			
			
			char cef02[8000]={0};
			
			re=Excute("00B0000000",resp);
			if (re!=0)
			{
				MessageBox("00B0ѧλ֤���ļ�--err");
				return;
			}
			
			strcpy(cef02,resp);
			sData+="ѧλ֤���ļ�:";
			sData+=cef02;
			sData+="\r\n";

		}
		break;
	case 0xADF6:
		{
			re=Exsten("270B","0A");
			if(re!=0)
			{
				MessageBox("�ⲿ��֤ʧ��");
				return ;
			}
			
			re=Excute("00A4000002EF01",resp);
			if (re!=0)
			{
				MessageBox("00A4000002EF01--err");
				return;
			}
			
			re=Excute("00B2010400",resp);
			if (re!=0)
			{
				MessageBox("00B0��ͨƱ���Ż���Ϣ--err");
				return;
			}
			char cef01[3000]={0};
			strcpy(cef01,resp);
			sData+="��ͨƱ���Ż���Ϣ:";
			sData+=cef01;
			sData+="\r\n";
			
			re=Excute("00A4000002EF02",resp);
			if (re!=0)
			{
				MessageBox("00A4000002EF02--err");
				return;
			}
			
			
			char cef02[8000]={0};
			
			re=Excute("00B2010400",resp);
			if (re!=0)
			{
				MessageBox("00B0��ͨƱ��ʹ����Ϣ--err");
				return;
			}
			
			strcpy(cef02,resp);
			sData+="��ͨƱ��ʹ����Ϣ:";
			sData+=cef02;
			sData+="\r\n";
		}
		break;
	case 0xADF9:
		{
			re=Exsten("270D","0A");
			if(re!=0)
			{
				MessageBox("�ⲿ��֤ʧ��");
				return ;
			}

			sData+="�ļ�������Ϣ";
			sData+="\r\n";
		}

	}


	CString temp("");
	GetDlgItemText(IDC_RICHEDIT1,temp);
	str+="\r\n";
	str+=sData;
	str+="\r\n";
	str+="----------------------------------";
	str+="\r\n";
	str+=temp;
	str+="\r\n";
	m_rich.SetWindowText(str);
	
}

void CEducationDemoDlg::OnWriteADF() 
{

	
}
int CEducationDemoDlg::UpdateWithMac(char *EsamIndex,char *Cmd)
{
	int re=0;
	char resp[1000]={0};
	unsigned char Resp[100]={0};
	char Random[50]={0};
	char Random2[50]={0};
	char RandomSAM[50]={0};
	char fsdata1[300]={0};
	char fsdata2[300]={0};
	char cmd[500]={0};
	char endata[100]={0};
	char endata_left[50]={0};
	char endata_right[50]={0};
	char endata_new[50]={0};
	char MAC[50]={0};


	re=Excute("0084000008",resp);
	if (re!=0)
	{
		MessageBox("0084000008--err");
		return-1;
	}

	memcpy(fsdata1,"1122334455667788",16);
	memcpy(fsdata2,resp,16);


	re=ExcutePSAM("0084000008",resp);
	if (re!=0)
	{
		MessageBox("SAM-0084000008--err");
		return-1;
	}
	memcpy(Random,resp,16);



	memcpy(cmd,"801A270208",10);
	memcpy(cmd+4,EsamIndex,4);
	memcpy(cmd+10,fsdata1,16);
	re=ExcutePSAM(cmd,resp);
	if (re!=0)
	{
		MessageBox("SAM-801A270208--err");
		return-1;
	}

	memcpy(cmd,"80FA000010",10);
	memcpy(cmd+10,fsdata2,16);
	memcpy(cmd+26,"0000000000000000",16);
	re=ExcutePSAM(cmd,resp);
	if (re!=0)
	{
		MessageBox("SAM-80FA000010--err");
		return-1;
	}

	memcpy(endata,resp,32);

	memset(cmd,0,100);

	memcpy(cmd,"801A000C10",10);
	memcpy(cmd+10,endata,32);
	re=ExcutePSAM(cmd,resp);
	if (re!=0)
	{
		MessageBox("SAM-801A000C10--err");
		return-1;
	}

	memset(cmd,0,100);
	memcpy(cmd,"80FA000010",10);
	memcpy(cmd+10,Random,16);
	memcpy(cmd+26,"0000000000000000",16);
	re=ExcutePSAM(cmd,resp);
	if (re!=0)
	{
		MessageBox("SAM-80FA000010--err");
		return-1;
	}

	memcpy(endata_left,resp,16);
	memcpy(endata_right,resp+16,16);

	re=newhuo(endata_left,endata_right,endata_new);
	if(re!=0)
	{
		MessageBox("SAM-left_right--err");
		return -1;
	}

	memset(cmd,0,100);
	memcpy(cmd,"0082000B11",10);
	memcpy(cmd+6,Cmd,2);//
	memcpy(cmd+10,endata_new,16);
	memcpy(cmd+26,Random,16);
	memcpy(cmd+42,"00",2);
	re=Excute(cmd,resp);
	if (re!=0)
	{
		MessageBox("0082000A11--err");
		return -1;
	}
	return 0;
}
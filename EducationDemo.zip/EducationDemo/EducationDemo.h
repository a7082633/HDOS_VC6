// EducationDemo.h : main header file for the EDUCATIONDEMO application
//

#if !defined(AFX_EDUCATIONDEMO_H__61F9848D_4D14_4BB2_8F07_F4E3ED2A793A__INCLUDED_)
#define AFX_EDUCATIONDEMO_H__61F9848D_4D14_4BB2_8F07_F4E3ED2A793A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CEducationDemoApp:
// See EducationDemo.cpp for the implementation of this class
//
#include "SkinPPWTL.h"
class CEducationDemoApp : public CWinApp
{
public:
	CEducationDemoApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CEducationDemoApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CEducationDemoApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_EDUCATIONDEMO_H__61F9848D_4D14_4BB2_8F07_F4E3ED2A793A__INCLUDED_)

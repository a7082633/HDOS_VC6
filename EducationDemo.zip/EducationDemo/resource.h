//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by EducationDemo.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_EDUCATIONDEMO_DIALOG        102
#define IDR_MAINFRAME                   128
#define IDC_RICHEDIT1                   1000
#define IDC_IDauthentication            1001
#define IDC_IssueDocuments              1002
#define IDC_IssueDocumentsW             1003
#define IDC_CardAuthentication          1004
#define IDC_PIN                         1005
#define IDC_CardCode                    1006
#define IDC_AppLogo                     1007
#define IDC_AppEdition                  1008
#define IDC_CardLogo                    1009
#define IDC_CardNum                     1010
#define IDC_OpenDate                    1011
#define IDC_EffectiveDate               1012
#define IDC_FCI                         1013
#define IDC_StateCode                   1014
#define IDC_Semester                    1015
#define IDC_EffectiveDate5              1016
#define IDC_SetDate                     1017
#define IDC_SchoolSet                   1018
#define IDC_QLogo                       1019
#define IDC_AllTimes                    1020
#define IDC_OpenDate6                   1021
#define IDC_EndDate6                    1022
#define IDC_EatType                     1023
#define IDC_EatSet                      1024
#define IDC_SerialNum                   1025
#define IDC_LastUseTime                 1026
#define IDC_UseSet                      1027
#define IDC_AppLock                     1028
#define IDC_AppUnlock                   1029
#define IDC_ChangePIN                   1030
#define IDC_OldPin                      1031
#define IDC_NewPin                      1032
#define IDC_UnlockPin                   1033
#define IDC_Clear                       1034
#define IDC_ReadADF                     1035
#define IDC_WriteADF                    1037
#define IDC_Read                        1038

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1039
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif

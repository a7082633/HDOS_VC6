// EducationDemoDlg.h : header file
//

#if !defined(AFX_EDUCATIONDEMODLG_H__0CA65424_873B_431F_9D00_90C1F22D1978__INCLUDED_)
#define AFX_EDUCATIONDEMODLG_H__0CA65424_873B_431F_9D00_90C1F22D1978__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CEducationDemoDlg dialog

class CEducationDemoDlg : public CDialog
{
// Construction
public:
	CEducationDemoDlg(CWnd* pParent = NULL);	// standard constructor

public:
	int Excute(char *cmd, char *Response);
	int ExcutePSAM(char *cmd, char *Response);
	int ExcuteASC(char *cmd, char *OutData);
	int OpenUSB();
	int newhuo(char *leftdata,char *rightdata,char *newdata);
	int AutP();
	int Exsten(char *EsamIndex,char *UserIndex);
	int UpdateWithMac(char *EsamIndex,char *Cmd);

// Dialog Data
	//{{AFX_DATA(CEducationDemoDlg)
	enum { IDD = IDD_EDUCATIONDEMO_DIALOG };
	CComboBox	m_cread;
	CRichEditCtrl	m_rich;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CEducationDemoDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CEducationDemoDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnIDauthentication();
	afx_msg void OnIssueDocuments();
	afx_msg void OnIssueDocumentsW();
	afx_msg void OnCardAuthentication();
	afx_msg void OnSchoolSet();
	afx_msg void OnEatSet();
	afx_msg void OnUseSet();
	afx_msg void OnAppLock();
	afx_msg void OnAppUnlock();
	afx_msg void OnChangePIN();
	afx_msg void OnUnlockPin();
	afx_msg void OnClear();
	afx_msg void OnReadADF();
	afx_msg void OnWriteADF();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_EDUCATIONDEMODLG_H__0CA65424_873B_431F_9D00_90C1F22D1978__INCLUDED_)
